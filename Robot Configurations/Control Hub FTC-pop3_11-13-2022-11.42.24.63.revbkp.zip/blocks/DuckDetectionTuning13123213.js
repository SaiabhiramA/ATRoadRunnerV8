var recognitions, xPosition_Left, location2, recognition, xPosition_Right;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  vuforiaCurrentGameAccess.initialize_withWebcam_2("Webcam 1", '', false, false, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  tfodCurrentGameAccess.initialize(vuforiaCurrentGameAccess, 0.7, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodCurrentGameAccess.activate();
  tfodCurrentGameAccess.setZoom(1.1, 16 / 9);
  location2 = 'RIGHT';
  telemetryAddTextData('DS preview on/off', '3 dots, Camera Stream');
  telemetryAddTextData('>', 'Press Play to start');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      InitializeDuckDetection();
    }
  }
  tfodCurrentGameAccess.deactivate();
}

/**
 * Describe this function...
 */
function InitializeDuckDetection() {
  // Get a list of recognitions from TFOD.
  recognitions = JSON.parse(tfodCurrentGameAccess.getRecognitions());
  // If list is empty, inform the user. Otherwise, go
  // through list and display info for each recognition.
  if (recognitions.length == 0) {
    location2 = 'RIGHT';
  } else {
    // Iterate through list and call a function to
    // display info for each recognized object.
    for (var recognition_index in recognitions) {
      recognition = recognitions[recognition_index];
      if (recognition.Label == 'Duck') {
        determineLocation();
      }
    }
  }
  telemetryAddTextData('duck position', location2);
  telemetryAddTextData('duck right position', xPosition_Right);
  telemetryAddTextData('duck left position', xPosition_Left);
  telemetry.update();
}

/**
 * Describe this function...
 */
function determineLocation() {
  linearOpMode.sleep(5000);
  xPosition_Left = miscAccess.roundDecimal(recognition.Left, 0);
  xPosition_Right = miscAccess.roundDecimal(recognition.Right, 0);
  if (xPosition_Left >= 30 && xPosition_Left <= 100) {
    location2 = 'LEFT';
  } else if (xPosition_Left >= 285 && xPosition_Left <= 450) {
    location2 = 'CENTER';
  } else {
    location2 = 'RIGHT';
  }
}
