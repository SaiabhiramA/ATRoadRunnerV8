/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  rearLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    rearLeftAsDcMotor.setDualPower(-0.5, rearRightAsDcMotor, -0.5);
    frontLeftAsDcMotor.setDualPower(-0.5, frontRightAsDcMotor, -0.5);
    linearOpMode.sleep(1500);
    frontRightAsDcMotor.setDualPower(0, frontLeftAsDcMotor, 0);
    rearLeftAsDcMotor.setDualPower(0, rearRightAsDcMotor, 0);
    linearOpMode.sleep(500);
    frontLeftAsDcMotor.setDualPower(0.5, frontRightAsDcMotor, -0.5);
    rearLeftAsDcMotor.setDualPower(-0.5, rearRightAsDcMotor, 0.5);
    linearOpMode.sleep(250);
    frontRightAsDcMotor.setDualPower(0, frontLeftAsDcMotor, 0);
    rearLeftAsDcMotor.setDualPower(0, rearRightAsDcMotor, 0);
  }
}
