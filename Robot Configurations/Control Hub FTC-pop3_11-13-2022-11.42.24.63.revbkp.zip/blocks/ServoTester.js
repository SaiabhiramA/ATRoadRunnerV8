// IDENTIFIERS_USED=clawAsServo,wristAsServo

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
  }
  wristAsServo.setPosition(0.9);
  while (linearOpMode.opModeIsActive()) {
    telemetry.update();
    clawAsServo.setPosition(1);
    linearOpMode.sleep(2000);
    clawAsServo.setPosition(0.75);
    linearOpMode.sleep(2000);
    telemetryAddTextData('Claw Position Live :', clawAsServo.getPosition());
    telemetry.update();
  }
}
