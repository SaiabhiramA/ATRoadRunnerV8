/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  rightAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    if (gamepad1.getA()) {
      leftAsDcMotor.setDualPower(0.79, rightAsDcMotor, 1);
    }
    if (gamepad1.getB()) {
      leftAsDcMotor.setDualPower(-0.79, rightAsDcMotor, -1);
    }
  }
}
