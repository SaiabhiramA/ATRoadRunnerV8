/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  arm1AsDcMotor.setZeroPowerBehavior("BRAKE");
  arm1AsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  arm1AsDcMotor.setTargetPosition(-5000);
  arm1AsDcMotor.setMode("RUN_TO_POSITION");
  arm1AsDcMotor.setVelocity(1000);
  while (!armuptouchAsTouchSensor.getIsPressed()) {
    telemetry.addNumericData('Reset Arm Position', arm1AsDcMotor.getCurrentPosition());
    telemetry.update();
  }
  linearOpMode.waitForStart();
  arm1AsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  if (linearOpMode.opModeIsActive()) {
    telemetry.addNumericData('After Op Mode is Active', arm1AsDcMotor.getCurrentPosition());
    telemetry.update();
    while (linearOpMode.opModeIsActive()) {
      if (gamepad1.getRightTrigger() > 0 && !armdowntouchAsTouchSensor.getIsPressed()) {
        arm1AsDcMotor.setTargetPosition(arm1AsDcMotor.getTargetPosition() + 100);
        arm1AsDcMotor.setMode("RUN_TO_POSITION");
        arm1AsDcMotor.setVelocity(1000);
      } else if (gamepad1.getRightTrigger() > 0 && !armuptouchAsTouchSensor.getIsPressed()) {
        arm1AsDcMotor.setTargetPosition(arm1AsDcMotor.getTargetPosition() - 100);
        arm1AsDcMotor.setMode("RUN_TO_POSITION");
        arm1AsDcMotor.setVelocity(1000);
      }
      telemetry.addNumericData('After Trigger is Pressed', arm1AsDcMotor.getCurrentPosition());
      telemetry.update();
    }
  }
}
