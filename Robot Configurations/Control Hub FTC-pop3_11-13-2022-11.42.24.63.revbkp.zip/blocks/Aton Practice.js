/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  frontLeftAsDcMotor.setDirection("REVERSE");
  rearLeftAsDcMotor.setDirection("REVERSE");
  frontRightAsDcMotor.setZeroPowerBehavior("BRAKE");
  frontLeftAsDcMotor.setZeroPowerBehavior("BRAKE");
  rearLeftAsDcMotor.setZeroPowerBehavior("BRAKE");
  rearRightAsDcMotor.setZeroPowerBehavior("BRAKE");
  if (linearOpMode.opModeIsActive()) {
    frontRightAsDcMotor.setDualPower(1, frontLeftAsDcMotor, 1);
    rearLeftAsDcMotor.setDualPower(1, rearRightAsDcMotor, 1);
    linearOpMode.sleep(1000);
    frontRightAsDcMotor.setDualPower(1, frontLeftAsDcMotor, -1);
    rearLeftAsDcMotor.setDualPower(-1, rearRightAsDcMotor, 1);
    linearOpMode.sleep(370);
    frontRightAsDcMotor.setDualPower(1, frontLeftAsDcMotor, 1);
    rearLeftAsDcMotor.setDualPower(1, rearRightAsDcMotor, 1);
    linearOpMode.sleep(1000);
    frontRightAsDcMotor.setDualPower(1, frontLeftAsDcMotor, -1);
    rearLeftAsDcMotor.setDualPower(-1, rearRightAsDcMotor, 1);
    linearOpMode.sleep(370);
    frontRightAsDcMotor.setDualPower(1, frontLeftAsDcMotor, 1);
    rearLeftAsDcMotor.setDualPower(1, rearRightAsDcMotor, 1);
    linearOpMode.sleep(1000);
    frontRightAsDcMotor.setDualPower(1, frontLeftAsDcMotor, -1);
    rearLeftAsDcMotor.setDualPower(-1, rearRightAsDcMotor, 1);
    linearOpMode.sleep(370);
    frontRightAsDcMotor.setDualPower(1, frontLeftAsDcMotor, 1);
    rearLeftAsDcMotor.setDualPower(1, rearRightAsDcMotor, 1);
    linearOpMode.sleep(1000);
    frontRightAsDcMotor.setDualPower(1, frontLeftAsDcMotor, -1);
    rearLeftAsDcMotor.setDualPower(-1, rearRightAsDcMotor, 1);
    linearOpMode.sleep(370);
    frontRightAsDcMotor.setDualPower(0, frontLeftAsDcMotor, 0);
    rearLeftAsDcMotor.setDualPower(0, rearRightAsDcMotor, 0);
    while (linearOpMode.opModeIsActive()) {
      telemetry.update();
    }
  }
}
