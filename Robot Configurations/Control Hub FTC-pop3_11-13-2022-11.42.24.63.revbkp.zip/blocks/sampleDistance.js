// IDENTIFIERS_USED=gamepad1,sensorColorRangeAsREVColorRangeSensor

var gain, normalizedColors, color, hue, saturation, value;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  gain = 2;
  telemetryAddTextData('Color Distance Example', 'Press start to continue...');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      telemetry.addNumericData('Dist to tgt (cm)', sensorColorRangeAsREVColorRangeSensor.getDistance("CM"));
      telemetry.addNumericData('Light detected', sensorColorRangeAsREVColorRangeSensor.getLightDetected());
      if (gamepad1.getA()) {
        gain = (typeof gain == 'number' ? gain : 0) + 0.005;
      } else if (gamepad1.getB() && gain >= 1.005) {
        gain = (typeof gain == 'number' ? gain : 0) + -0.005;
      }
      sensorColorRangeAsREVColorRangeSensor.setGain(gain);
      telemetry.addNumericData('Gain', sensorColorRangeAsREVColorRangeSensor.getGain());
      normalizedColors = JSON.parse(sensorColorRangeAsREVColorRangeSensor.getNormalizedColors());
      telemetry.addNumericData('Red', miscAccess.roundDecimal(startBlockExecution("NormalizedColors.Red") ? endBlockExecution(normalizedColors.Red) : 0, 3));
      telemetry.addNumericData('Green', miscAccess.roundDecimal(startBlockExecution("NormalizedColors.Green") ? endBlockExecution(normalizedColors.Green) : 0, 3));
      telemetry.addNumericData('Blue', miscAccess.roundDecimal(startBlockExecution("NormalizedColors.Blue") ? endBlockExecution(normalizedColors.Blue) : 0, 3));
      color = startBlockExecution("NormalizedColors.Color") ? endBlockExecution(normalizedColors.Color) : 0;
      hue = colorAccess.getHue(color);
      saturation = colorAccess.getSaturation(color);
      value = colorAccess.getValue(color);
      telemetry.addNumericData('Hue', miscAccess.roundDecimal(hue, 0));
      telemetry.addNumericData('Saturation', miscAccess.roundDecimal(saturation, 3));
      telemetry.addNumericData('Value', miscAccess.roundDecimal(value, 3));
      telemetry.addNumericData('Alpha', miscAccess.roundDecimal(startBlockExecution("NormalizedColors.Alpha") ? endBlockExecution(normalizedColors.Alpha) : 0, 3));
      colorAccess.showColor(color);
      if (hue < 30) {
        telemetryAddTextData('Color', 'Red');
      } else if (hue < 60) {
        telemetryAddTextData('Color', 'Orange');
      } else if (hue < 90) {
        telemetryAddTextData('Color', 'Yellow');
      } else if (hue < 150) {
        telemetryAddTextData('Color', 'Green');
      } else if (hue < 225) {
        telemetryAddTextData('Color', 'Blue');
      } else if (hue < 350) {
        telemetryAddTextData('Color', 'purple');
      } else {
        telemetryAddTextData('Color', 'Red');
      }
      if (saturation < 0.2) {
        telemetryAddTextData('Check Sat', 'Is surface white?');
      }
      telemetry.update();
      if (value < 0.16) {
        telemetryAddTextData('Check Val', 'Is surface black?');
      }
    }
    colorAccess.showColor(colorAccess.textToColor('white'));
  }
}
