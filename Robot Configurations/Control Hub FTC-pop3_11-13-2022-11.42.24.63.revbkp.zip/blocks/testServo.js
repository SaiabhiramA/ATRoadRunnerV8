// IDENTIFIERS_USED=clawAsServo,gamepad1

var ServoPosition, ServoSpeed;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  ServoPosition = 0.5;
  ServoSpeed = 0.01;
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    if (gamepad1.getB()) {
      ServoPosition = (typeof ServoPosition == 'number' ? ServoPosition : 0) + ServoSpeed;
    }
    if (gamepad1.getX()) {
      ServoPosition = (typeof ServoPosition == 'number' ? ServoPosition : 0) + -ServoSpeed;
    }
    ServoPosition = Math.min(Math.max(ServoPosition, 0), 1);
    clawAsServo.setPosition(ServoPosition);
    telemetry.addNumericData('Servo', ServoPosition);
    telemetry.update();
    linearOpMode.sleep(20);
  }
}
