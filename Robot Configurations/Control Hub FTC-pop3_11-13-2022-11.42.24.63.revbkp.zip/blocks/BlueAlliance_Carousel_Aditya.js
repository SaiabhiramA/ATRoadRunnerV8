var LeftTicks, RightTicks, Velocity, Yaw_Angle, imuParameters;

/**
 * Describe this function...
 */
function Moving_to_BlueParking() {
  RobotMove(441, 914, 500);
  RobotMove(1408, 1865, 500);
}

/**
 * Describe this function...
 */
function SpinCarousel() {
  flywheelservoAsCRServo.setPower(-1);
  leftAsDcMotor.setDualPower(-0.3, rightAsDcMotor, -0.3);
  telemetryAddTextData('Is Dropping the Duck?', 'Yes');
  telemetry.update();
  linearOpMode.sleep(8000);
  flywheelservoAsCRServo.setPower(0);
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  rightAsDcMotor.setDirection("REVERSE");
  rightAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftAsDcMotor, "STOP_AND_RESET_ENCODER");
  armMotorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    MovetoHub();
    DropBlock();
    MovetoCarousel();
    SpinCarousel();
    Moving_to_BlueParking();
  }
}

/**
 * Describe this function...
 */
function MovetoCarousel() {
  RobotMove(1282, 3115, 500);
  armMotorAsDcMotor.setPower(0);
  linearOpMode.sleep(4000);
  RobotMove(1859, 2455, 500);
  RobotMove(728, 1338, 500);
  RobotMove(659, 1378, 500);
  RobotMove(330, 990, 500);
}

/**
 * Describe this function...
 */
function DropBlock() {
  flapperMotorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  flapperMotorAsDcMotor.setTargetPosition(-600);
  flapperMotorAsDcMotor.setMode("RUN_TO_POSITION");
  flapperMotorAsDcMotor.setVelocity(2000);
  while (flapperMotorAsDcMotor.isBusy()) {
    telemetryAddTextData('Is Dropping the Block?', 'Yes');
    telemetry.addNumericData('Flapper Velocity ', leftAsDcMotor.getVelocity());
    telemetryAddTextData('Position', flapperMotorAsDcMotor.getCurrentPosition());
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function MovetoHub() {
  RobotMove(1015, 1011, 500);
  RobotMove(728, 1338, 500);
  RobotMove(1859, 2455, 500);
  RobotMove(1282, 3115, 500);
  armMotorAsDcMotor.setTargetPosition(400);
  armMotorAsDcMotor.setMode("RUN_TO_POSITION");
  armMotorAsDcMotor.setVelocity(400);
  RobotMove(2725, 4457, 500);
  linearOpMode.sleep(3000);
}

/**
 * Describe this function...
 */
function RobotMove(LeftTicks, RightTicks, Velocity) {
  rightAsDcMotor.setDualTargetPosition(RightTicks, leftAsDcMotor, LeftTicks);
  rightAsDcMotor.setDualMode("RUN_TO_POSITION", leftAsDcMotor, "RUN_TO_POSITION");
  leftAsDcMotor.setDualVelocity(2000, rightAsDcMotor, 2000);
  while (leftAsDcMotor.isBusy() || rightAsDcMotor.isBusy()) {
    telemetryAddTextData('Is Moving to Blue Parking?', 'Yes');
    telemetry.addNumericData('Robot Velocity ', leftAsDcMotor.getVelocity());
    telemetryAddTextData('Position', leftAsDcMotor.getCurrentPosition());
    telemetryAddTextData('Position', rightAsDcMotor.getCurrentPosition());
    telemetryAddTextData('is at the target', !leftAsDcMotor.isBusy());
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function Initialize_IMU() {
  imuParameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setAngleUnit(imuParameters, "DEGREES");
  bno055imuParametersAccess.setAccelUnit(imuParameters, "METERS_PERSEC_PERSEC");
  bno055imuParametersAccess.setLoggingEnabled(imuParameters, false);
  imuAsBNO055IMU.initialize(imuParameters);
  while (!IMU_Calibrated()) {
    telemetryAddTextData('If calibration ', 'doesn\'t complete after 3 seconds, move through 90 degree pitch, roll and yaw motions until calibration complete ');
    telemetry.update();
    linearOpMode.sleep(1000);
  }
  telemetryAddTextData('Status', 'Calibration Complete');
  telemetry.update();
  Set_Yaw_Angle();
}

/**
 * Describe this function...
 */
function IMU_Calibrated() {
  telemetryAddTextData('IMU Calibration Status', imuAsBNO055IMU.getCalibrationStatus());
  telemetryAddTextData('Gyro Calibrated', imuAsBNO055IMU.isGyroCalibrated() ? 'True' : 'False');
  telemetryAddTextData('System Status', imuAsBNO055IMU.getSystemStatus());
}

/**
 * Describe this function...
 */
function Set_Yaw_Angle() {
  Yaw_Angle = orientationAccess.getFirstAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "ZYX", "DEGREES"));
}
