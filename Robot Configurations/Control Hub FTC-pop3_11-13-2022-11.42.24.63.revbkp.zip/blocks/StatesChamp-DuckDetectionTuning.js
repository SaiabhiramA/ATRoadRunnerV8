var recognitions, location2, recognition, xPosition_Left, xPosition_Right, IsDetected;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  ActivateDuckDetection();
  telemetryAddTextData('DS preview on/off', '3 dots, Camera Stream');
  telemetryAddTextData('>', 'Press Play to start');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    location2 = 'RIGHT';
    IsDetected = false;
    while (linearOpMode.opModeIsActive()) {
      DetectDuckLocation();
      telemetryAddTextData('duck position', location2);
      telemetryAddTextData('duck right position', xPosition_Right);
      telemetryAddTextData('duck left position', xPosition_Left);
      telemetry.update();
    }
  }
  DeActivateDuckDetection();
}

/**
 * Describe this function...
 */
function ActivateDuckDetection() {
  vuforiaCurrentGameAccess.initialize_withWebcam_2("Webcam 1", '', false, false, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  tfodCurrentGameAccess.initialize(vuforiaCurrentGameAccess, 0.7, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodCurrentGameAccess.activate();
  tfodCurrentGameAccess.setZoom(1.05, 16 / 9);
}

/**
 * Describe this function...
 */
function DetectDuckLocation() {
  // Get a list of recognitions from TFOD.
  recognitions = JSON.parse(tfodCurrentGameAccess.getRecognitions());
  // If list is empty, inform the user. Otherwise, go
  // through list and display info for each recognition.
  if (recognitions.length == 0) {
    location2 = 'RIGHT';
  } else {
    // Iterate through list and call a function to
    // display info for each recognized object.
    for (var recognition_index in recognitions) {
      recognition = recognitions[recognition_index];
      if (recognition.Label == 'Duck') {
        xPosition_Left = miscAccess.roundDecimal(recognition.Left, 0);
        xPosition_Right = miscAccess.roundDecimal(recognition.Right, 0);
        if (xPosition_Left >= 10 && xPosition_Left <= 120) {
          location2 = 'LEFT';
        } else if (xPosition_Left >= 285 && xPosition_Left <= 450) {
          location2 = 'CENTER';
        } else {
          location2 = 'GOOFY RIGHT';
        }
        IsDetected = true;
      }
    }
  }
}

/**
 * Describe this function...
 */
function DeActivateDuckDetection() {
  tfodCurrentGameAccess.deactivate();
}
