// IDENTIFIERS_USED=arm1AsDcMotor,arm2AsDcMotor,clawAsServo,clawrotateAsServo,gamepad1,turntableAsDcMotor

var ElbowPosition, ElbowSpeed, WaistPosition, WaistSpeed, ArmPosition, ArmSpeed, ClawSpeed, ClawPosition, WristSpeed, WristPosition;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  ElbowPosition = 0;
  ElbowSpeed = 50;
  WaistPosition = 0;
  WaistSpeed = 10;
  ArmPosition = 0;
  ArmSpeed = 50;
  ClawSpeed = 0.01;
  ClawPosition = 0.1;
  WristSpeed = 0.01;
  WristPosition = 0.1;
  arm1AsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  arm2AsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  turntableAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    if (gamepad1.getDpadUp()) {
      WristPosition = (typeof WristPosition == 'number' ? WristPosition : 0) + WristSpeed;
      telemetry.addNumericData('DpadUp', 'Pressed');
    }
    if (gamepad1.getDpadDown()) {
      WristPosition = (typeof WristPosition == 'number' ? WristPosition : 0) + -WristSpeed;
      telemetry.addNumericData('DpadDown', 'Pressed');
    }
    if (gamepad1.getDpadRight()) {
      ClawPosition = (typeof ClawPosition == 'number' ? ClawPosition : 0) + ClawSpeed;
      telemetry.addNumericData('DpadRight', 'Pressed');
    }
    if (gamepad1.getDpadLeft()) {
      ClawPosition = (typeof ClawPosition == 'number' ? ClawPosition : 0) + -ClawSpeed;
      telemetry.addNumericData('DpadLeft', 'Pressed');
    }
    if (gamepad1.getLeftTrigger() > 0 && !gamepad1.getLeftBumper()) {
      ArmPosition = (typeof ArmPosition == 'number' ? ArmPosition : 0) + -ArmSpeed;
      telemetry.addNumericData('Left Trigger Arm Down', 'Pressed');
    }
    if (gamepad1.getRightTrigger() > 0 && !gamepad1.getRightBumper()) {
      ArmPosition = (typeof ArmPosition == 'number' ? ArmPosition : 0) + ArmSpeed;
      telemetry.addNumericData('Right Trigger Arm Up', 'Pressed');
    }
    if (gamepad1.getLeftTrigger() == 0 && gamepad1.getLeftBumper()) {
      ElbowPosition = (typeof ElbowPosition == 'number' ? ElbowPosition : 0) + -ElbowSpeed;
      telemetry.addNumericData('Left Bumper Elbow Down', 'Pressed');
    }
    if (gamepad1.getRightTrigger() == 0 && gamepad1.getRightBumper()) {
      ElbowPosition = (typeof ElbowPosition == 'number' ? ElbowPosition : 0) + ElbowSpeed;
      telemetry.addNumericData('Right Bumper Elbow Up', 'Pressed');
    }
    if (gamepad1.getLeftTrigger() > 0 && gamepad1.getLeftBumper()) {
      WaistPosition = (typeof WaistPosition == 'number' ? WaistPosition : 0) + WaistSpeed;
      telemetry.addNumericData('Waist Left', 'Pressed');
    }
    if (gamepad1.getRightTrigger() > 0 && gamepad1.getRightBumper()) {
      WaistPosition = (typeof WaistPosition == 'number' ? WaistPosition : 0) + -WaistSpeed;
      telemetry.addNumericData('Waist Right', 'Pressed');
    }
    ClawPosition = Math.min(Math.max(ClawPosition, 0), 1);
    WristPosition = Math.min(Math.max(WristPosition, 0), 1);
    clawrotateAsServo.setPosition(WristPosition);
    clawAsServo.setPosition(ClawPosition);
    arm1AsDcMotor.setTargetPosition(ArmPosition);
    arm1AsDcMotor.setMode("RUN_TO_POSITION");
    arm1AsDcMotor.setVelocity(5000);
    arm2AsDcMotor.setTargetPosition(ElbowPosition);
    arm2AsDcMotor.setMode("RUN_TO_POSITION");
    arm2AsDcMotor.setVelocity(5000);
    turntableAsDcMotor.setTargetPosition(WaistPosition);
    turntableAsDcMotor.setMode("RUN_TO_POSITION");
    turntableAsDcMotor.setVelocity(5000);
    telemetry.addNumericData('wrist position', clawrotateAsServo.getPosition());
    telemetry.addNumericData('claw position', clawAsServo.getPosition());
    telemetry.addNumericData('arm position', arm1AsDcMotor.getCurrentPosition());
    telemetry.addNumericData('elbow position', ElbowPosition);
    telemetry.addNumericData('waist position', turntableAsDcMotor.getCurrentPosition());
    telemetry.update();
    linearOpMode.sleep(20);
  }
}
