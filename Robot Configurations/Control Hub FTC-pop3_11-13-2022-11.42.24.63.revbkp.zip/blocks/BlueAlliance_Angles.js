var LeftTicks, RightTicks, Angle, Yaw_Angle, imuParameters, CurrentLeftTicks, CurrentRightTicks;

/**
 * Describe this function...
 */
function SpinCarousel() {
  armMotorAsDcMotor.setPower(0);
  flywheelservoAsCRServo.setPower(-1);
  leftAsDcMotor.setDualPower(-0.3, rightAsDcMotor, -0.3);
  telemetryAddTextData('Is Dropping the Duck?', 'Yes');
  telemetry.update();
  linearOpMode.sleep(3000);
  flywheelservoAsCRServo.setPower(0);
}

/**
 * Describe this function...
 */
function Moving_to_BlueParking() {
  RobotMove(441, 914, -40.625);
  RobotMove(1408, 1865, -38.75);
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  Initialize_IMU();
  rightAsDcMotor.setDirection("REVERSE");
  rightAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", leftAsDcMotor, "STOP_AND_RESET_ENCODER");
  armMotorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    MovetoHub();
    DropBlock();
    MovetoCarousel();
    SpinCarousel();
    Moving_to_BlueParking();
  }
}

/**
 * Describe this function...
 */
function MovetoCarousel() {
  RobotMove(1282, 3115, -135.6875);
  RobotMove(1859, 2455, -45.625);
  RobotMove(728, 1338, -47.5625);
  RobotMove(659, 1378, -52.375);
  RobotMove(330, 990, -52.625);
}

/**
 * Describe this function...
 */
function DropBlock() {
  flapperMotorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  flapperMotorAsDcMotor.setTargetPosition(-600);
  flapperMotorAsDcMotor.setMode("RUN_TO_POSITION");
  flapperMotorAsDcMotor.setVelocity(2000);
  while (flapperMotorAsDcMotor.isBusy()) {
    telemetryAddTextData('Is Dropping the Block?', 'Yes');
    telemetry.addNumericData('Flapper Velocity ', leftAsDcMotor.getVelocity());
    telemetryAddTextData('Position', flapperMotorAsDcMotor.getCurrentPosition());
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function MovetoHub() {
  RobotMove(1015, 1011, -1.4375);
  RobotMove(728, 1338, -40.75);
  RobotMove(1859, 2455, -43.625);
  RobotMove(1282, 3115, -137.9375);
  armMotorAsDcMotor.setTargetPosition(400);
  armMotorAsDcMotor.setMode("RUN_TO_POSITION");
  armMotorAsDcMotor.setVelocity(400);
  RobotMove(2725, 4457, -133.0625);
}

/**
 * Describe this function...
 */
function RobotMove(LeftTicks, RightTicks, Angle) {
  rightAsDcMotor.setDualTargetPosition(RightTicks, leftAsDcMotor, LeftTicks);
  rightAsDcMotor.setDualMode("RUN_TO_POSITION", leftAsDcMotor, "RUN_TO_POSITION");
  leftAsDcMotor.setDualVelocity(1000, rightAsDcMotor, 1000);
  while (leftAsDcMotor.isBusy() || rightAsDcMotor.isBusy()) {
    CurrentLeftTicks = leftAsDcMotor.getCurrentPosition();
    CurrentLeftTicks = rightAsDcMotor.getCurrentPosition();
    Set_Yaw_Angle();
    telemetry.addNumericData('Left Velocity ', leftAsDcMotor.getVelocity());
    telemetry.addNumericData('Right Velocity ', rightAsDcMotor.getVelocity());
    telemetryAddTextData('Left Position', leftAsDcMotor.getCurrentPosition());
    telemetryAddTextData('Right Position', rightAsDcMotor.getCurrentPosition());
    telemetryAddTextData('Yaw Angle', Yaw_Angle);
    telemetryAddTextData('Target Reached', 'Yes');
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function Initialize_IMU() {
  imuParameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setAngleUnit(imuParameters, "DEGREES");
  bno055imuParametersAccess.setAccelUnit(imuParameters, "METERS_PERSEC_PERSEC");
  bno055imuParametersAccess.setLoggingEnabled(imuParameters, false);
  imuAsBNO055IMU.initialize(imuParameters);
  while (!IMU_Calibrated()) {
    telemetryAddTextData('If calibration ', 'doesn\'t complete after 3 seconds, move through 90 degree pitch, roll and yaw motions until calibration complete ');
    telemetry.update();
    linearOpMode.sleep(1000);
  }
  telemetryAddTextData('Status', 'Calibration Complete');
  telemetry.update();
}

/**
 * Describe this function...
 */
function IMU_Calibrated() {
  telemetryAddTextData('IMU Calibration Status', imuAsBNO055IMU.getCalibrationStatus());
  telemetryAddTextData('Gyro Calibrated', imuAsBNO055IMU.isGyroCalibrated() ? 'True' : 'False');
  telemetryAddTextData('System Status', imuAsBNO055IMU.getSystemStatus());
  return imuAsBNO055IMU.isGyroCalibrated();
}

/**
 * Describe this function...
 */
function Set_Yaw_Angle() {
  Yaw_Angle = orientationAccess.getFirstAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "ZYX", "DEGREES"));
}
