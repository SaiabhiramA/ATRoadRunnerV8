var Position, FrontLeftTicks, FrontRightTicks, RearLeftTicks, RearRightTicks, Velocity, Yaw_Angle, imuParameters, ArmVelocity, WheelVelocity;

/**
 * Describe this function...
 */
function Move_Arm_Position(Position) {
  if (Position == 1) {
    ArmmotorAsDcMotor.setTargetPosition(-9291);
    ArmmotorAsDcMotor.setMode("RUN_TO_POSITION");
    ArmmotorAsDcMotor.setVelocity(ArmVelocity);
  } else if (Position == 2) {
    ArmmotorAsDcMotor.setTargetPosition(-8546);
    ArmmotorAsDcMotor.setMode("RUN_TO_POSITION");
    ArmmotorAsDcMotor.setVelocity(ArmVelocity);
  } else if (Position == 3) {
    ArmmotorAsDcMotor.setTargetPosition(-7480);
    ArmmotorAsDcMotor.setMode("RUN_TO_POSITION");
    ArmmotorAsDcMotor.setVelocity(ArmVelocity);
  } else if (Position == 0) {
    ArmmotorAsDcMotor.setTargetPosition(-800);
    ArmmotorAsDcMotor.setMode("RUN_TO_POSITION");
    ArmmotorAsDcMotor.setVelocity(ArmVelocity);
  }
}

/**
 * Describe this function...
 */
function Moving_to_RedAllianceWarehouse() {
  Move_Arm_Position(0);
  RobotMove(517, -856, 1389, -1724, 500);
  RobotMove(3361, 2148, 4180, 1095, 2000);
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  Initialize_IMU();
  frontLeftAsDcMotor.setDirection("REVERSE");
  rearLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", frontRightAsDcMotor, "STOP_AND_RESET_ENCODER");
  rearLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rearRightAsDcMotor, "STOP_AND_RESET_ENCODER");
  ArmVelocity = 3000;
  WheelVelocity = 500;
  Reset_Arm();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    MovetoHub();
    DropBlock();
    Moving_to_RedAllianceWarehouse();
  }
}

/**
 * Describe this function...
 */
function DropBlock() {
  intakeAsDcMotor.setPower(-0.25);
  linearOpMode.sleep(1000);
  intakeAsDcMotor.setPower(0);
}

/**
 * Describe this function...
 */
function RobotMove(FrontLeftTicks, FrontRightTicks, RearLeftTicks, RearRightTicks, Velocity) {
  frontLeftAsDcMotor.setDualTargetPosition(FrontLeftTicks, frontRightAsDcMotor, FrontRightTicks);
  rearLeftAsDcMotor.setDualTargetPosition(RearLeftTicks, rearRightAsDcMotor, RearRightTicks);
  frontLeftAsDcMotor.setDualMode("RUN_TO_POSITION", frontRightAsDcMotor, "RUN_TO_POSITION");
  rearLeftAsDcMotor.setDualMode("RUN_TO_POSITION", rearRightAsDcMotor, "RUN_TO_POSITION");
  frontLeftAsDcMotor.setDualVelocity(Velocity, frontRightAsDcMotor, Velocity);
  rearLeftAsDcMotor.setDualVelocity(Velocity, rearRightAsDcMotor, Velocity);
  while (frontLeftAsDcMotor.isBusy() || frontRightAsDcMotor.isBusy() || rearLeftAsDcMotor.isBusy() || rearRightAsDcMotor.isBusy()) {
    Set_Yaw_Angle();
    telemetryAddTextData('Yaw Angle', Yaw_Angle);
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function Initialize_IMU() {
  imuParameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setAngleUnit(imuParameters, "DEGREES");
  bno055imuParametersAccess.setAccelUnit(imuParameters, "METERS_PERSEC_PERSEC");
  bno055imuParametersAccess.setLoggingEnabled(imuParameters, false);
  imuAsBNO055IMU.initialize(imuParameters);
  while (!IMU_Calibrated()) {
    telemetryAddTextData('If calibration ', 'doesn\'t complete after 3 seconds, move through 90 degree pitch, roll and yaw motions until calibration complete ');
    telemetry.update();
    linearOpMode.sleep(1000);
  }
  telemetryAddTextData('Status', 'Calibration Complete');
  telemetry.update();
}

/**
 * Describe this function...
 */
function MovetoHub() {
  RobotMove(358, 359, 358, 353, 500);
  RobotMove(-39, 765, 773, -44, 500);
  RobotMove(1858, -1159, 2671, -1951, 1000);
  Move_Arm_Position(3);
  RobotMove(1489, -1543, 2313, -2338, 500);
  RobotMove(1337, -1699, 2164, -2486, 500);
}

/**
 * Describe this function...
 */
function IMU_Calibrated() {
  telemetryAddTextData('IMU Calibration Status', imuAsBNO055IMU.getCalibrationStatus());
  telemetryAddTextData('Gyro Calibrated', imuAsBNO055IMU.isGyroCalibrated() ? 'True' : 'False');
  telemetryAddTextData('System Status', imuAsBNO055IMU.getSystemStatus());
  return imuAsBNO055IMU.isGyroCalibrated();
}

/**
 * Describe this function...
 */
function Set_Yaw_Angle() {
  Yaw_Angle = orientationAccess.getFirstAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "ZYX", "DEGREES"));
}

/**
 * Describe this function...
 */
function Reset_Arm() {
  ArmmotorAsDcMotor.setTargetPosition(12000);
  ArmmotorAsDcMotor.setMode("RUN_TO_POSITION");
  ArmmotorAsDcMotor.setVelocity(ArmVelocity);
  while (!armtouchsensorAsTouchSensor.getIsPressed()) {
    telemetry.addNumericData('Reset Arm Position', ArmmotorAsDcMotor.getCurrentPosition());
  }
  ArmmotorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  ArmmotorAsDcMotor.setTargetPosition(-800);
  ArmmotorAsDcMotor.setMode("RUN_TO_POSITION");
  ArmmotorAsDcMotor.setVelocity(ArmVelocity);
}
