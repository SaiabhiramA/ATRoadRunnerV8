// IDENTIFIERS_USED=armdowntouchAsTouchSensor,armuptouchAsTouchSensor,elbowtouchAsTouchSensor,turntabletouchAsTouchSensor

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      telemetryAddTextData('Elbow Touch', elbowtouchAsTouchSensor.getIsPressed());
      telemetryAddTextData('Arm Up Touch', armuptouchAsTouchSensor.getIsPressed());
      telemetryAddTextData('Arm down touch', armdowntouchAsTouchSensor.getIsPressed());
      telemetryAddTextData('Turn Table Touch', turntabletouchAsTouchSensor.getIsPressed());
      telemetry.update();
    }
  }
}
