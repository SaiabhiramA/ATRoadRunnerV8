var Position, turntableposition, FrontLeftTicks, FrontRightTicks, RearLeftTicks, RearRightTicks, Velocity, recognitions, Yaw_Angle, AutoTurnTable, AutoArm, imuParameters, location2, recognition, xPosition, TurnTableVelocity, ArmVelocity, xPosition_Right, IsDetected, WheelPower, AutoIntake, RobotPosition;

/**
 * Describe this function...
 */
function ResetArmNTurnTableAuto() {
  intakeboxAsServo.setPosition(0.27);
  ResetArmUp();
  ResetTurnTable();
  ResetArmDown();
}

/**
 * Describe this function...
 */
function IMU_Calibrated() {
  telemetryAddTextData('IMU Calibration Status', imuAsBNO055IMU.getCalibrationStatus());
  telemetryAddTextData('Gyro Calibrated', imuAsBNO055IMU.isGyroCalibrated() ? 'True' : 'False');
  telemetryAddTextData('System Status', imuAsBNO055IMU.getSystemStatus());
  return imuAsBNO055IMU.isGyroCalibrated();
}

/**
 * Describe this function...
 */
function Move_ArmShippingHub_Auto(Position) {
  if (Position == 'A') {
    SetArmPosition(-996);
  } else if (Position == 'B') {
    SetArmPosition(-1987);
  } else if (Position == 'Y') {
    SetArmPosition(-3167);
  } else if (Position == 'X') {
    SetArmPosition(-1300);
  }
}

/**
 * Describe this function...
 */
function DeActivateDuckDetection() {
  tfodCurrentGameAccess.deactivate();
}

/**
 * Describe this function...
 */
function DetectDuckLocation() {
  // Get a list of recognitions from TFOD.
  recognitions = JSON.parse(tfodCurrentGameAccess.getRecognitions());
  // If list is empty, inform the user. Otherwise, go
  // through list and display info for each recognition.
  if (recognitions.length == 0) {
    location2 = 'RIGHT';
  } else {
    // Iterate through list and call a function to
    // display info for each recognized object.
    for (var recognition_index in recognitions) {
      recognition = recognitions[recognition_index];
      if (recognition.Label == 'Duck') {
        xPosition = miscAccess.roundDecimal(recognition.Left, 0);
        xPosition_Right = miscAccess.roundDecimal(recognition.Right, 0);
        if (xPosition >= 10 && xPosition <= 120) {
          location2 = 'LEFT';
        } else if (xPosition >= 285 && xPosition <= 450) {
          location2 = 'CENTER';
        } else {
          location2 = 'GOOFY RIGHT';
        }
        IsDetected = true;
      }
    }
    telemetryAddTextData('duck position', location2);
    telemetryAddTextData('duck right position', xPosition_Right);
    telemetryAddTextData('duck left position', xPosition);
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function ResetTurnTable() {
  if (!turntabletouchAsTouchSensor.getIsPressed()) {
    turntableAsDcMotor.setTargetPosition(-5000);
    turntableAsDcMotor.setMode("RUN_TO_POSITION");
    turntableAsDcMotor.setVelocity(5000);
    while (!turntabletouchAsTouchSensor.getIsPressed()) {
      telemetry.addNumericData('Reset Turn Table Position', turntableAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
    turntableAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    SetTurnTablePosition(500);
  }
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  ActivateDuckDetection();
  frontLeftAsDcMotor.setDirection("REVERSE");
  rearLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDualZeroPowerBehavior("BRAKE", frontRightAsDcMotor, "BRAKE");
  rearLeftAsDcMotor.setDualZeroPowerBehavior("BRAKE", rearRightAsDcMotor, "BRAKE");
  intakeAsDcMotor.setZeroPowerBehavior("BRAKE");
  carosuelmoterAsDcMotor.setZeroPowerBehavior("BRAKE");
  intakeAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  frontLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", frontRightAsDcMotor, "STOP_AND_RESET_ENCODER");
  rearLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rearRightAsDcMotor, "STOP_AND_RESET_ENCODER");
  ArmVelocity = 5000;
  TurnTableVelocity = 5000;
  WheelPower = 0.5;
  AutoArm = false;
  AutoIntake = false;
  AutoTurnTable = false;
  RobotPosition = 'R';
  location2 = 'RIGHT';
  ResetArmNTurnTableAuto();
  Initialize_IMU();
  DetectDuckLocation();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    intakeAsDcMotor.setPower(-0.1);
    MovetoHub();
    MoveTurnTablePosition(3948);
    DropBlock();
    MovetoCarousel();
    Red_alliance_carousel();
    Moving_to_RedAllianceWarehouse();
    telemetry.update();
  }
  DeActivateDuckDetection();
}

/**
 * Describe this function...
 */
function MoveTurnTablePosition(turntableposition) {
  SetArmPosition(-1000);
  SetTurnTablePosition(turntableposition);
}

/**
 * Describe this function...
 */
function Set_Yaw_Angle() {
  Yaw_Angle = orientationAccess.getFirstAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "ZYX", "DEGREES"));
}

/**
 * Describe this function...
 */
function Initialize_IMU() {
  imuParameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setAngleUnit(imuParameters, "DEGREES");
  bno055imuParametersAccess.setAccelUnit(imuParameters, "METERS_PERSEC_PERSEC");
  bno055imuParametersAccess.setLoggingEnabled(imuParameters, false);
  imuAsBNO055IMU.initialize(imuParameters);
  while (!IMU_Calibrated()) {
    telemetryAddTextData('If calibration ', 'doesn\'t complete after 3 seconds, move through 90 degree pitch, roll and yaw motions until calibration complete ');
    telemetry.update();
    linearOpMode.sleep(1000);
  }
  telemetryAddTextData('Status', 'Calibration Complete');
  telemetry.update();
}

/**
 * Describe this function...
 */
function RobotMove(FrontLeftTicks, FrontRightTicks, RearLeftTicks, RearRightTicks, Velocity) {
  frontLeftAsDcMotor.setDualTargetPosition(FrontLeftTicks, frontRightAsDcMotor, FrontRightTicks);
  rearLeftAsDcMotor.setDualTargetPosition(RearLeftTicks, rearRightAsDcMotor, RearRightTicks);
  frontLeftAsDcMotor.setDualMode("RUN_TO_POSITION", frontRightAsDcMotor, "RUN_TO_POSITION");
  rearLeftAsDcMotor.setDualMode("RUN_TO_POSITION", rearRightAsDcMotor, "RUN_TO_POSITION");
  frontLeftAsDcMotor.setDualVelocity(Velocity, frontRightAsDcMotor, Velocity);
  rearLeftAsDcMotor.setDualVelocity(Velocity, rearRightAsDcMotor, Velocity);
  while (frontLeftAsDcMotor.isBusy() || frontRightAsDcMotor.isBusy() || rearLeftAsDcMotor.isBusy() || rearRightAsDcMotor.isBusy()) {
    Display_Key_Measures();
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function ResetArmUp() {
  if (!armuptouchAsTouchSensor.getIsPressed()) {
    armAsDcMotor.setTargetPosition(-5000);
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(5000);
    while (!armuptouchAsTouchSensor.getIsPressed()) {
      telemetry.addNumericData('Reset Arm Position', armAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
    armAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  }
}

/**
 * Describe this function...
 */
function ResetArmDown() {
  if (!armdowntouchAsTouchSensor.getIsPressed()) {
    armAsDcMotor.setTargetPosition(5000);
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(5000);
    while (!armdowntouchAsTouchSensor.getIsPressed()) {
      telemetry.addNumericData('Reset Arm Position', armAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
    armAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    SetArmPosition(-100);
  }
}

/**
 * Describe this function...
 */
function ActivateDuckDetection() {
  vuforiaCurrentGameAccess.initialize_withWebcam_2("Webcam 1", '', false, false, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  tfodCurrentGameAccess.initialize(vuforiaCurrentGameAccess, 0.7, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodCurrentGameAccess.activate();
  tfodCurrentGameAccess.setZoom(1.05, 16 / 9);
}

/**
 * Describe this function...
 */
function Red_alliance_carousel() {
  carosuelmoterAsDcMotor.setPower(-0.05);
  for (var count = 0; count < 5; count++) {
    carosuelmoterAsDcMotor.setPower(carosuelmoterAsDcMotor.getPower() - 0.05);
    linearOpMode.sleep(250);
  }
}

/**
 * Describe this function...
 */
function MovetoHub() {
  RobotMove(368, 363, 370, 372, 500);
  RobotMove(-1341, 2009, -1313, 1957, 500);
  RobotMove(-2864, 600, -2819, 498, 500);
  RobotMove(-2226, 1199, -2187, 1117, 500);
  RobotMove(-3326, 2343, -3282, 2231, 500);
  RobotMove(-3044, 2112, -3599, 2609, 500);
}

/**
 * Describe this function...
 */
function DropBlock() {
  if (location2 == 'CENTER') {
    telemetryAddTextData('Center', 'Center');
    Move_ArmShippingHub_Auto('B');
    intakeboxAsServo.setPosition(0.649);
  } else if (location2 == 'LEFT') {
    telemetryAddTextData('Lower', 'Lower');
    Move_ArmShippingHub_Auto('A');
    intakeboxAsServo.setPosition(0.8247);
  } else {
    telemetryAddTextData('Top', 'Top');
    Move_ArmShippingHub_Auto('Y');
    intakeboxAsServo.setPosition(0.38);
  }
  intakeAsDcMotor.setPower(0.25);
  linearOpMode.sleep(3000);
  intakeAsDcMotor.setPower(0);
}

/**
 * Describe this function...
 */
function SetArmPosition(Position) {
  AutoArm = true;
  armAsDcMotor.setTargetPosition(Position);
  armAsDcMotor.setMode("RUN_TO_POSITION");
  armAsDcMotor.setVelocity(ArmVelocity);
  while (!(armAsDcMotor.getCurrentPosition() == Position || !armdowntouchAsTouchSensor.getIsPressed() || !armuptouchAsTouchSensor.getIsPressed())) {
  }
}

/**
 * Describe this function...
 */
function Moving_to_RedAllianceWarehouse() {
  RobotMove(-3925, 1240, -4474, 1713, 500);
  RobotMove(-4286, 1538, -5143, 2300, 500);
  ResetArmNTurnTableAuto();
  RobotMove(-3401, 2400, -4279, 3211, 500);
  RobotMove(-4359, 3117, -3494, 2352, 500);
}

/**
 * Describe this function...
 */
function Display_Key_Measures() {
  telemetryAddTextData('Front Left Position', frontLeftAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Front Right Position', frontRightAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Rear Left Position', rearLeftAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Rear Right Position', rearRightAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Turn Table', turntableAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Arm', armAsDcMotor.getCurrentPosition());
  Set_Yaw_Angle();
  telemetry.addNumericData('Yaw Angle', Yaw_Angle);
  telemetry.addNumericData('Intake Box Position', intakeboxAsServo.getPosition());
}

/**
 * Describe this function...
 */
function SetTurnTablePosition(Position) {
  AutoTurnTable = true;
  turntableAsDcMotor.setTargetPosition(Position);
  turntableAsDcMotor.setMode("RUN_TO_POSITION");
  turntableAsDcMotor.setVelocity(TurnTableVelocity);
  while (!(turntableAsDcMotor.getCurrentPosition() == Position || !turntabletouchAsTouchSensor.getIsPressed())) {
  }
}

/**
 * Describe this function...
 */
function MovetoCarousel() {
  RobotMove(-4342, 819, -4883, 1268, 500);
}
