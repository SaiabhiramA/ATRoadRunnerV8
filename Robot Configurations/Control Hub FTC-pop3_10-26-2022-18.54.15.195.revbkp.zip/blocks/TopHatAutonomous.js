var action, speed, armpos, Position, boxpos, Alliance, Counter, recognitions, ducklocation, ArmVelocity, TurnTableVelocity, IsDetected, recognition, xPosition_Right, xPosition, WheelPower, AutoArm, AutoIntake, AutoTurnTable, RobotPosition, IsArmPositionReady;

/**
 * Describe this function...
 */
function initializeRobot() {
  ActivateDuckDetection();
  intakeAsDcMotor.setZeroPowerBehavior("BRAKE");
  carosuelmoterAsDcMotor.setZeroPowerBehavior("BRAKE");
  intakeAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  carosuelmoterAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  ArmVelocity = 5000;
  TurnTableVelocity = 5000;
  WheelPower = 0.5;
  AutoArm = false;
  AutoIntake = false;
  AutoTurnTable = false;
  RobotPosition = 'R';
  ducklocation = 'RIGHT';
  IsArmPositionReady = false;
  ResetArmNTurnTableAuto();
  DetectDuckLocation();
}

/**
 * Describe this function...
 */
function DetectDuckLocation() {
  Counter = 0;
  // Get a list of recognitions from TFOD.
  recognitions = JSON.parse(tfodCurrentGameAccess.getRecognitions());
  while (Counter < 600) {
    // Get a list of recognitions from TFOD.
    recognitions = JSON.parse(tfodCurrentGameAccess.getRecognitions());
    Counter = Counter + 1;
    // Iterate through list and call a function to
    // display info for each recognized object.
    for (var recognition_index in recognitions) {
      recognition = recognitions[recognition_index];
      if (recognition.Label == 'Duck') {
        xPosition = miscAccess.roundDecimal(recognition.Left, 0);
        xPosition_Right = miscAccess.roundDecimal(recognition.Right, 0);
        if (xPosition >= 10 && xPosition <= 120) {
          ducklocation = 'LEFT';
        } else if (xPosition >= 285 && xPosition <= 475) {
          ducklocation = 'CENTER';
        } else {
          ducklocation = 'GOOFY RIGHT';
        }
        IsDetected = true;
      }
    }
    if (IsDetected == true) {
      break;
    }
  }
  // If list is empty, inform the user. Otherwise, go
  // through list and display info for each recognition.
  if (IsDetected != true) {
    ducklocation = 'RIGHT';
  }
  telemetryAddTextData('Checked for object # of Times', Counter);
  telemetryAddTextData('duck position', ducklocation);
  telemetryAddTextData('duck right position', xPosition_Right);
  telemetryAddTextData('duck left position', xPosition);
  telemetryAddTextData('Please press play now', 'PLAY');
  telemetry.update();
}

/**
 * Describe this function...
 */
function ResetArmNTurnTableAuto() {
  setIntakeBoxPosition('R');
  if (turntableAsDcMotor.getCurrentPosition() > 300 && armAsDcMotor.getCurrentPosition() < -100) {
    ResetArmUp();
    ResetTurnTable();
    ResetArmDown();
  }
}

/**
 * Describe this function...
 */
function IntakeAction(action, speed) {
  if (action == 'I') {
    intakeAsDcMotor.setPower(speed);
  } else if (action == 'O') {
    intakeAsDcMotor.setPower(speed);
  } else if (action == 'R') {
    intakeAsDcMotor.setPower(speed);
  }
  linearOpMode.sleep(2000);
}

/**
 * Describe this function...
 */
function Red_alliance_carousel() {
  carosuelmoterAsDcMotor.setPower(-0.05);
  for (var count = 0; count < 4; count++) {
    carosuelmoterAsDcMotor.setPower(carosuelmoterAsDcMotor.getPower() - 0.05);
    linearOpMode.sleep(250);
  }
  carosuelmoterAsDcMotor.setPower(0);
}

/**
 * Describe this function...
 */
function setArmDropPosition(armpos) {
  if (armpos == 'L') {
    SetArmPosition(-996);
  } else if (armpos == 'M') {
    SetArmPosition(-1987);
  } else if (armpos == 'T') {
    SetArmPosition(-3167);
    telemetryAddTextData('Top Shelf', armAsDcMotor.getCurrentPosition());
  } else if (armpos == 'W') {
    SetArmPosition(-200);
  }
}

/**
 * Describe this function...
 */
function MoveTurnTablePosition() {
  SetArmPosition(-1500);
  SetTurnTablePosition(4386);
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  initializeRobot();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    IntakeAction('R', -0.1);
    MoveTurnTablePosition();
    DropBlock();
    Red_alliance_carousel();
    Blue_alliance_carousel();
    Display_Key_Measures();
    telemetry.update();
  }
  DeActivateDuckDetection();
}

/**
 * Describe this function...
 */
function ResetTurnTable() {
  if (!turntabletouchAsTouchSensor.getIsPressed()) {
    turntableAsDcMotor.setTargetPosition(-5000);
    turntableAsDcMotor.setMode("RUN_TO_POSITION");
    turntableAsDcMotor.setVelocity(TurnTableVelocity);
    while (!turntabletouchAsTouchSensor.getIsPressed()) {
    }
    turntableAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    SetTurnTablePosition(300);
  }
}

/**
 * Describe this function...
 */
function Blue_alliance_carousel() {
  carosuelmoterAsDcMotor.setPower(0.05);
  for (var count2 = 0; count2 < 4; count2++) {
    carosuelmoterAsDcMotor.setPower(carosuelmoterAsDcMotor.getPower() + 0.05);
    linearOpMode.sleep(250);
  }
  carosuelmoterAsDcMotor.setPower(0);
}

/**
 * Describe this function...
 */
function SetArmPosition(Position) {
  armAsDcMotor.setTargetPosition(Position);
  armAsDcMotor.setMode("RUN_TO_POSITION");
  armAsDcMotor.setVelocity(ArmVelocity);
  while (!(armAsDcMotor.getCurrentPosition() == Position || armdowntouchAsTouchSensor.getIsPressed() || armuptouchAsTouchSensor.getIsPressed())) {
  }
}

/**
 * Describe this function...
 */
function ResetArmUp() {
  if (!armuptouchAsTouchSensor.getIsPressed()) {
    armAsDcMotor.setTargetPosition(-5000);
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(ArmVelocity);
    while (!armuptouchAsTouchSensor.getIsPressed()) {
    }
    armAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  }
}

/**
 * Describe this function...
 */
function setIntakeBoxPosition(boxpos) {
  if (boxpos == 'T') {
    intakeboxAsServo.setPosition(0.38);
  } else if (boxpos == 'M') {
    intakeboxAsServo.setPosition(0.649);
  } else if (boxpos == 'L') {
    intakeboxAsServo.setPosition(0.89);
  } else if (boxpos == 'B') {
    intakeboxAsServo.setPosition(0.38);
  } else if (boxpos == 'I') {
    intakeboxAsServo.setPosition(0.649);
  } else if (boxpos == 'R') {
    intakeboxAsServo.setPosition(0.27);
  }
}

/**
 * Describe this function...
 */
function AutoSpinCarousel(Alliance) {
  if (Alliance == 'RED') {
    Red_alliance_carousel();
  }
  if (Alliance == 'BLUE') {
    Blue_alliance_carousel();
  }
  carosuelmoterAsDcMotor.setPower(0);
}

/**
 * Describe this function...
 */
function DeActivateDuckDetection() {
  tfodCurrentGameAccess.deactivate();
}

/**
 * Describe this function...
 */
function SetTurnTablePosition(Position) {
  turntableAsDcMotor.setTargetPosition(Position);
  turntableAsDcMotor.setMode("RUN_TO_POSITION");
  turntableAsDcMotor.setVelocity(TurnTableVelocity);
  while (!(turntableAsDcMotor.getCurrentPosition() == Position || turntabletouchAsTouchSensor.getIsPressed())) {
  }
}

/**
 * Describe this function...
 */
function ActivateDuckDetection() {
  vuforiaCurrentGameAccess.initialize_withWebcam_2("Webcam 1", '', false, false, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  tfodCurrentGameAccess.initialize(vuforiaCurrentGameAccess, 0.7, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodCurrentGameAccess.activate();
  tfodCurrentGameAccess.setZoom(1.05, 16 / 9);
}

/**
 * Describe this function...
 */
function DropBlock() {
  if (ducklocation == 'CENTER') {
    telemetryAddTextData('Center', 'Center');
    setArmDropPosition('M');
    setIntakeBoxPosition('M');
  } else if (ducklocation == 'LEFT') {
    telemetryAddTextData('Lower', 'Lower');
    setArmDropPosition('L');
    setIntakeBoxPosition('L');
  } else {
    telemetryAddTextData('Top', 'Top');
    setArmDropPosition('T');
    setIntakeBoxPosition('T');
  }
  IntakeAction('O', 0.25);
  intakeAsDcMotor.setPower(0);
  setArmDropPosition('W');
  telemetry.update();
}

/**
 * Describe this function...
 */
function Display_Key_Measures() {
  telemetryAddTextData('Front Left Position', frontLeftAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Front Right Position', frontRightAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Rear Left Position', rearLeftAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Rear Right Position', rearRightAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Turn Table', turntableAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Arm', armAsDcMotor.getCurrentPosition());
  telemetry.addNumericData('Intake Box Position', intakeboxAsServo.getPosition());
}

/**
 * Describe this function...
 */
function ResetArmDown() {
  if (!armdowntouchAsTouchSensor.getIsPressed()) {
    armAsDcMotor.setTargetPosition(5000);
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(ArmVelocity);
    while (!armdowntouchAsTouchSensor.getIsPressed()) {
    }
    armAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    SetArmPosition(-100);
  }
}
