/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  rearLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDirection("REVERSE");
  rearRightAsDcMotor.setZeroPowerBehavior("BRAKE");
  rearLeftAsDcMotor.setZeroPowerBehavior("BRAKE");
  frontLeftAsDcMotor.setZeroPowerBehavior("BRAKE");
  frontRightAsDcMotor.setZeroPowerBehavior("BRAKE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    frontRightAsDcMotor.setDualPower(1, rearLeftAsDcMotor, -1);
    rearRightAsDcMotor.setDualPower(1, frontLeftAsDcMotor, -1);
    linearOpMode.sleep(370);
    rearRightAsDcMotor.setDualPower(0, frontLeftAsDcMotor, 0);
    frontRightAsDcMotor.setDualPower(0, rearLeftAsDcMotor, 0);
    while (linearOpMode.opModeIsActive()) {
      telemetry.update();
    }
  }
}
