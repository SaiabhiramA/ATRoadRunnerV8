var Position, power, turntableposition, TurnTableCurrentPosition, ArmCurrentPosition, AutoTurnTable, AutoArm, imuParameters, Yaw_Angle, WheelPower, ArmVelocity, TurnTableVelocity, IsIntakeBoxSet, IntakeBoxPosition, RobotPosition, AutoIntake;

/**
 * Describe this function...
 */
function MoveArmManual() {
  TurnTableCurrentPosition = turntableAsDcMotor.getCurrentPosition();
  ArmCurrentPosition = armAsDcMotor.getCurrentPosition();
  if (gamepad2.getLeftTrigger() > 0 && gamepad2.getLeftBumper() != true && !armuptouchAsTouchSensor.getIsPressed()) {
    AutoArm = false;
    armAsDcMotor.setTargetPosition(armAsDcMotor.getTargetPosition() - targetposition(gamepad2.getLeftTrigger()));
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(1000);
  } else if (gamepad2.getRightTrigger() > 0 && gamepad2.getRightBumper() != true && ArmCurrentPosition < -450 && !armdowntouchAsTouchSensor.getIsPressed()) {
    telemetry.addNumericData('Yes less than -450', ArmCurrentPosition);
    ArmCurrentPosition = armAsDcMotor.getCurrentPosition();
    if (TurnTableCurrentPosition < 450 && TurnTableCurrentPosition > 150 || TurnTableCurrentPosition < 8750 && TurnTableCurrentPosition > 8550) {
      AutoArm = false;
      armAsDcMotor.setTargetPosition(armAsDcMotor.getTargetPosition() + targetposition(gamepad2.getRightTrigger()));
      armAsDcMotor.setMode("RUN_TO_POSITION");
      armAsDcMotor.setVelocity(1000);
    }
  } else if (AutoArm == false) {
    armAsDcMotor.setTargetPosition(armAsDcMotor.getCurrentPosition());
    armAsDcMotor.setVelocity(armAsDcMotor.getVelocity());
  }
}

/**
 * Describe this function...
 */
function Move_Intake_Manually() {
  if (gamepad2.getRightStickX() != 0 && gamepad2.getRightBumper() == false) {
    if (gamepad2.getRightStickX() > 0) {
      SetIntakeBoxPosition();
      intakeAsDcMotor.setPower(0.25);
    } else if (gamepad2.getRightStickX() < 0) {
      SetIntakeBoxPosition();
      intakeAsDcMotor.setPower(-0.75);
    }
  } else {
    intakeAsDcMotor.setPower(0);
    IsIntakeBoxSet = false;
  }
}

/**
 * Describe this function...
 */
function Move_Carousel() {
  if (gamepad1.getLeftBumper() == true && gamepad1.getLeftStickX() != 0) {
    carosuelmoterAsDcMotor.setPower(1 * gamepad2.getLeftStickX());
  } else {
    carosuelmoterAsDcMotor.setPower(0);
  }
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  frontLeftAsDcMotor.setDirection("REVERSE");
  rearLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDualZeroPowerBehavior("BRAKE", frontRightAsDcMotor, "BRAKE");
  rearLeftAsDcMotor.setDualZeroPowerBehavior("BRAKE", rearRightAsDcMotor, "BRAKE");
  intakeAsDcMotor.setZeroPowerBehavior("BRAKE");
  carosuelmoterAsDcMotor.setZeroPowerBehavior("BRAKE");
  intakeAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  frontLeftAsDcMotor.setDualMode("RUN_WITHOUT_ENCODER", frontRightAsDcMotor, "RUN_WITHOUT_ENCODER");
  rearLeftAsDcMotor.setDualMode("RUN_WITHOUT_ENCODER", rearRightAsDcMotor, "RUN_WITHOUT_ENCODER");
  ArmVelocity = 3000;
  TurnTableVelocity = 3000;
  WheelPower = 0.5;
  AutoArm = false;
  AutoIntake = false;
  AutoTurnTable = false;
  IsIntakeBoxSet = false;
  InitializeIMU();
  ResetArmNTurnTableAuto();
  RobotPosition = 'R';
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    SetTurnTablePosition('C');
    while (linearOpMode.opModeIsActive()) {
      DriveOverall();
      AligntoShippingHubs();
      AutoSpinCarousel();
      Move_Intake_Manually();
      MoveToIntakePosition();
      CheckNSetTurboMode();
      MoveArmManual();
      MoveTurnTableManual();
      telemetry.update();
    }
  }
}

/**
 * Describe this function...
 */
function Move_ArmShippingHub_Auto(Position) {
  if (Position == 'A') {
    SetArmPosition(-996);
  } else if (Position == 'B') {
    SetArmPosition(-1987);
  } else if (Position == 'Y') {
    SetArmPosition(-3167);
  } else if (Position == 'X') {
    SetArmPosition(-500);
  }
}

/**
 * Describe this function...
 */
function Wheel_Power(power) {
  return WheelPower * power;
}

/**
 * Describe this function...
 */
function Arm_Velocity(power) {
  return ArmVelocity * power;
}

/**
 * Describe this function...
 */
function AutoSpinCarousel() {
  if (gamepad1.getY()) {
    carosuelmoterAsDcMotor.setPower(-0.05);
    for (var count = 0; count < 8; count++) {
      carosuelmoterAsDcMotor.setPower(carosuelmoterAsDcMotor.getPower() - 0.05);
      linearOpMode.sleep(250);
    }
  }
  if (gamepad1.getA()) {
    carosuelmoterAsDcMotor.setPower(0.05);
    for (var count2 = 0; count2 < 8; count2++) {
      carosuelmoterAsDcMotor.setPower(carosuelmoterAsDcMotor.getPower() + 0.05);
      linearOpMode.sleep(250);
    }
  }
  carosuelmoterAsDcMotor.setPower(0);
}

/**
 * Describe this function...
 */
function MoveToIntakePosition() {
  if (gamepad2.getDpadDown() && gamepad2.getLeftBumper() != true) {
    SetTurnTablePosition('C');
    SetArmPosition(-50);
    intakeboxAsServo.setPosition(0.649);
    IntakeBoxPosition = 'I';
  }
}

/**
 * Describe this function...
 */
function TurnTableVelocity2(power) {
  return TurnTableVelocity * power;
}

/**
 * Describe this function...
 */
function targetposition(power) {
  return 10000 * power;
}

/**
 * Describe this function...
 */
function MoveRobotDirection() {
  if (gamepad2.getDpadUp() && gamepad2.getLeftBumper() != true) {
    SetTurnTablePosition('C');
  } else if (gamepad2.getDpadLeft() && gamepad2.getLeftBumper() != true) {
    SetTurnTablePosition('L');
  } else if (gamepad2.getDpadRight() && gamepad2.getLeftBumper() != true) {
    SetTurnTablePosition('R');
  }
}

/**
 * Describe this function...
 */
function SetIntakeBoxPosition() {
  if (IsIntakeBoxSet != true) {
    if (IntakeBoxPosition == 'T') {
      intakeboxAsServo.setPosition(0.38);
      IsIntakeBoxSet = true;
    } else if (IntakeBoxPosition == 'M') {
      intakeboxAsServo.setPosition(0.649);
      IsIntakeBoxSet = true;
    } else if (IntakeBoxPosition == 'L') {
      intakeboxAsServo.setPosition(0.89);
      IsIntakeBoxSet = true;
    } else if (IntakeBoxPosition == 'B') {
      intakeboxAsServo.setPosition(0.38);
      IsIntakeBoxSet = true;
    } else if (IntakeBoxPosition == 'I') {
      intakeboxAsServo.setPosition(0.649);
      IsIntakeBoxSet = true;
    }
  }
}

/**
 * Describe this function...
 */
function MoveTurnTableManual() {
  ArmCurrentPosition = armAsDcMotor.getCurrentPosition();
  TurnTableCurrentPosition = turntableAsDcMotor.getCurrentPosition();
  if (ArmCurrentPosition < -1000) {
    if (TurnTableCurrentPosition < 8700 && gamepad2.getLeftTrigger() > 0 && gamepad2.getLeftBumper() == true) {
      AutoTurnTable = false;
      turntableAsDcMotor.setTargetPosition(turntableAsDcMotor.getTargetPosition() + targetposition(gamepad2.getLeftTrigger()));
      turntableAsDcMotor.setMode("RUN_TO_POSITION");
      turntableAsDcMotor.setVelocity(1000);
    } else if (TurnTableCurrentPosition > 200 && gamepad2.getRightTrigger() > 0 && gamepad2.getRightBumper() == true) {
      AutoTurnTable = false;
      turntableAsDcMotor.setTargetPosition(turntableAsDcMotor.getTargetPosition() - targetposition(gamepad2.getRightTrigger()));
      turntableAsDcMotor.setMode("RUN_TO_POSITION");
      turntableAsDcMotor.setVelocity(1000);
    } else if (AutoTurnTable == false) {
      turntableAsDcMotor.setTargetPosition(turntableAsDcMotor.getCurrentPosition());
      turntableAsDcMotor.setVelocity(turntableAsDcMotor.getVelocity());
    }
  }
}

/**
 * Describe this function...
 */
function Zero_Power_Wheels() {
  frontLeftAsDcMotor.setDualPower(0, frontRightAsDcMotor, 0);
  rearLeftAsDcMotor.setDualPower(0, rearRightAsDcMotor, 0);
}

/**
 * Describe this function...
 */
function CheckNSetTurboMode() {
  if (gamepad1.getB()) {
    WheelPower = 1;
  } else if (gamepad1.getX()) {
    WheelPower = 0.5;
  }
}

/**
 * Describe this function...
 */
function TuneIntakeBox() {
  if (gamepad2.getRightStickX() > 0 && gamepad2.getRightBumper() == true) {
    intakeboxAsServo.setPosition(gamepad2.getRightStickX());
  }
}

/**
 * Describe this function...
 */
function TurnTablePosition(turntableposition) {
  if (turntableposition == 'C') {
    if (RobotPosition != 'C') {
      SetArmPosition(-1500);
      Zero_Power_Wheels();
      while (!(armAsDcMotor.getCurrentPosition() == -1500)) {
      }
      SetTurnTablePosition(4350);
      Zero_Power_Wheels();
      while (!(turntableAsDcMotor.getCurrentPosition() == 4350)) {
      }
      RobotPosition = 'C';
    }
  } else if (turntableposition == 'L') {
    if (RobotPosition != 'L') {
      SetArmPosition(-1500);
      Zero_Power_Wheels();
      while (!(armAsDcMotor.getCurrentPosition() == -1500)) {
      }
      SetTurnTablePosition(8500);
      Zero_Power_Wheels();
      while (!(turntableAsDcMotor.getCurrentPosition() == 8500)) {
      }
      RobotPosition = 'L';
    }
  } else if (turntableposition == 'R') {
    if (RobotPosition != 'R') {
      SetArmPosition(-1500);
      Zero_Power_Wheels();
      while (!(armAsDcMotor.getCurrentPosition() == -1500)) {
      }
      SetTurnTablePosition(500);
      Zero_Power_Wheels();
      while (!(turntableAsDcMotor.getCurrentPosition() == 500)) {
      }
      RobotPosition = 'R';
    }
  }
}

/**
 * Describe this function...
 */
function DriveOverall() {
  if (gamepad1.getLeftTrigger() > 0) {
    frontLeftAsDcMotor.setDualPower(Wheel_Power(-gamepad1.getLeftTrigger()), frontRightAsDcMotor, Wheel_Power(-gamepad1.getLeftTrigger()));
    rearLeftAsDcMotor.setDualPower(Wheel_Power(-gamepad1.getLeftTrigger()), rearRightAsDcMotor, Wheel_Power(-gamepad1.getLeftTrigger()));
  } else if (gamepad1.getLeftStickX() != 0 && gamepad1.getLeftBumper() == false) {
    frontLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getLeftStickX()), frontRightAsDcMotor, Wheel_Power(-gamepad1.getLeftStickX()));
    rearLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getLeftStickX()), rearRightAsDcMotor, Wheel_Power(-gamepad1.getLeftStickX()));
  } else if (gamepad1.getRightTrigger() > 0) {
    frontLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getRightTrigger()), frontRightAsDcMotor, Wheel_Power(gamepad1.getRightTrigger()));
    rearLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getRightTrigger()), rearRightAsDcMotor, Wheel_Power(gamepad1.getRightTrigger()));
  } else if (gamepad1.getRightStickX() != 0) {
    frontLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getRightStickX()), frontRightAsDcMotor, Wheel_Power(-gamepad1.getRightStickX()));
    rearLeftAsDcMotor.setDualPower(Wheel_Power(-gamepad1.getRightStickX()), rearRightAsDcMotor, Wheel_Power(gamepad1.getRightStickX()));
  } else if (gamepad1.getLeftBumper() == true && gamepad1.getLeftStickY() != 0) {
    frontLeftAsDcMotor.setDualPower(0, frontRightAsDcMotor, Wheel_Power(gamepad1.getLeftStickY()));
    rearLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getLeftStickY()), rearRightAsDcMotor, 0);
  } else if (gamepad1.getRightBumper() == true && gamepad1.getRightStickY() != 0) {
    frontLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getRightStickY()), frontRightAsDcMotor, 0);
    rearLeftAsDcMotor.setDualPower(0, rearRightAsDcMotor, Wheel_Power(gamepad1.getRightStickY()));
  } else {
    Zero_Power_Wheels();
  }
}

/**
 * Describe this function...
 */
function AligntoShippingHubs() {
  if (gamepad2.getA()) {
    Move_ArmShippingHub_Auto('A');
  } else if (gamepad2.getB()) {
    Move_ArmShippingHub_Auto('B');
  } else if (gamepad2.getY()) {
    TurnTablePosition('L');
    Move_ArmShippingHub_Auto('Y');
  } else if (gamepad2.getX()) {
    TurnTablePosition('L');
    Move_ArmShippingHub_Auto('X');
  }
}

/**
 * Describe this function...
 */
function ResetEncoders() {
  if (gamepad1.getDpadUp() == true) {
    frontLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", frontRightAsDcMotor, "STOP_AND_RESET_ENCODER");
    rearLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rearRightAsDcMotor, "STOP_AND_RESET_ENCODER");
    frontLeftAsDcMotor.setDualMode("RUN_WITHOUT_ENCODER", frontRightAsDcMotor, "RUN_WITHOUT_ENCODER");
    rearLeftAsDcMotor.setDualMode("RUN_WITHOUT_ENCODER", rearRightAsDcMotor, "RUN_WITHOUT_ENCODER");
    turntableAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    armAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  }
}

/**
 * Describe this function...
 */
function SetTurnTablePosition(Position) {
  AutoTurnTable = true;
  turntableAsDcMotor.setTargetPosition(Position);
  turntableAsDcMotor.setMode("RUN_TO_POSITION");
  turntableAsDcMotor.setVelocity(TurnTableVelocity);
}

/**
 * Describe this function...
 */
function SetArmPosition(Position) {
  AutoArm = true;
  armAsDcMotor.setTargetPosition(Position);
  armAsDcMotor.setMode("RUN_TO_POSITION");
  armAsDcMotor.setVelocity(ArmVelocity);
}

/**
 * Describe this function...
 */
function MoveIntakeBoxManually() {
  if (gamepad2.getLeftBumper() == true && gamepad2.getDpadUp() == true) {
    intakeboxAsServo.setPosition(0.38);
    IntakeBoxPosition = 'T';
  } else if (gamepad2.getLeftBumper() == true && gamepad2.getDpadRight() == true) {
    intakeboxAsServo.setPosition(0.649);
    IntakeBoxPosition = 'M';
  } else if (gamepad2.getLeftBumper() == true && gamepad2.getDpadLeft() == true) {
    intakeboxAsServo.setPosition(0.89);
    IntakeBoxPosition = 'L';
  } else if (gamepad2.getLeftBumper() == true && gamepad2.getDpadDown() == true) {
    IntakeBoxPosition = 'B';
    intakeboxAsServo.setPosition(0.38);
  }
}

/**
 * Describe this function...
 */
function InitializeIMU() {
  imuParameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setAngleUnit(imuParameters, "DEGREES");
  bno055imuParametersAccess.setAccelUnit(imuParameters, "METERS_PERSEC_PERSEC");
  bno055imuParametersAccess.setLoggingEnabled(imuParameters, false);
  imuAsBNO055IMU.initialize(imuParameters);
  telemetryAddTextData('IMU Example', 'Press start to continue...');
  telemetry.update();
}

/**
 * Describe this function...
 */
function Set_Yaw_Angle() {
  Yaw_Angle = orientationAccess.getFirstAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "ZYX", "DEGREES"));
}

/**
 * Describe this function...
 */
function Reset_ArmNTurnTableManually() {
  if (gamepad1.getLeftBumper() && gamepad1.getRightBumper() && gamepad1.getLeftTrigger() > 0 && gamepad1.getRightTrigger() > 0) {
    ResetArmNTurnTableAuto();
  }
}

/**
 * Describe this function...
 */
function Display_Key_Measures() {
  telemetryAddTextData('Front Left Position', frontLeftAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Front Right Position', frontRightAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Rear Left Position', rearLeftAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Rear Right Position', rearRightAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Turn Table', turntableAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Arm', armAsDcMotor.getCurrentPosition());
  Set_Yaw_Angle();
  telemetry.addNumericData('Yaw Angle', Yaw_Angle);
  telemetry.addNumericData('Intake Box Position', intakeboxAsServo.getPosition());
}

/**
 * Describe this function...
 */
function ResetArmDown() {
  if (!armdowntouchAsTouchSensor.getIsPressed()) {
    armAsDcMotor.setTargetPosition(5000);
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(ArmVelocity);
    while (!armdowntouchAsTouchSensor.getIsPressed()) {
      telemetry.addNumericData('Reset Arm Position', armAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
    armAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    SetArmPosition(0);
  }
}

/**
 * Describe this function...
 */
function ResetTurnTable() {
  if (!turntabletouchAsTouchSensor.getIsPressed()) {
    turntableAsDcMotor.setTargetPosition(-5000);
    turntableAsDcMotor.setMode("RUN_TO_POSITION");
    turntableAsDcMotor.setVelocity(TurnTableVelocity);
    while (!turntabletouchAsTouchSensor.getIsPressed()) {
      telemetry.addNumericData('Reset Turn Table Position', turntableAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
    turntableAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    SetTurnTablePosition(100);
  }
}

/**
 * Describe this function...
 */
function ResetArmUp() {
  if (!armuptouchAsTouchSensor.getIsPressed()) {
    armAsDcMotor.setTargetPosition(-5000);
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(ArmVelocity);
    while (!armuptouchAsTouchSensor.getIsPressed()) {
      telemetry.addNumericData('Reset Arm Position', armAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
    armAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    SetArmPosition(80);
  }
}

/**
 * Describe this function...
 */
function ResetArmNTurnTableAuto() {
  intakeboxAsServo.setPosition(0.27);
  ResetArmUp();
  ResetTurnTable();
  ResetArmDown();
}
