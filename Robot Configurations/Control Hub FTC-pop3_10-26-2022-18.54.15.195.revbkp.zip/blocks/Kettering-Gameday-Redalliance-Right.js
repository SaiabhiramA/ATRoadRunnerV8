var Position, FrontLeftTicks, FrontRightTicks, RearLeftTicks, RearRightTicks, Velocity, turntableposition, xPosition, AutoArm, AutoTurnTable, Yaw_Angle, imuParameters, location2, recognition, ArmVelocity, TurnTableVelocity, RobotPosition, recognitions, WheelPower, AutoIntake;

/**
 * Describe this function...
 */
function MoveTurnTablePosition(turntableposition) {
  SetArmPosition(-1000);
  while (!(armAsDcMotor.getCurrentPosition() < -1000)) {
  }
  if (turntableposition == 'C' && RobotPosition != 'C' && armAsDcMotor.getCurrentPosition() <= -1000) {
    SetTurnTablePosition(4350);
    RobotPosition = 'C';
    while (!(turntableAsDcMotor.getCurrentPosition() == 4350)) {
    }
  } else if (turntableposition == 'L' && RobotPosition != 'L' && armAsDcMotor.getCurrentPosition() <= -1000) {
    SetTurnTablePosition(8500);
    RobotPosition = 'L';
    while (!(turntableAsDcMotor.getCurrentPosition() == 8500)) {
    }
  } else if (turntableposition == 'R' && RobotPosition != 'R' && armAsDcMotor.getCurrentPosition() <= -1000) {
    SetTurnTablePosition(500);
    RobotPosition = 'R';
    while (!(turntableAsDcMotor.getCurrentPosition() == 500)) {
    }
  }
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  frontLeftAsDcMotor.setDirection("REVERSE");
  rearLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDualZeroPowerBehavior("BRAKE", frontRightAsDcMotor, "BRAKE");
  rearLeftAsDcMotor.setDualZeroPowerBehavior("BRAKE", rearRightAsDcMotor, "BRAKE");
  intakeAsDcMotor.setZeroPowerBehavior("BRAKE");
  carosuelmoterAsDcMotor.setZeroPowerBehavior("BRAKE");
  intakeAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  frontLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", frontRightAsDcMotor, "STOP_AND_RESET_ENCODER");
  rearLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rearRightAsDcMotor, "STOP_AND_RESET_ENCODER");
  ResetArmNTurnTableAuto();
  ArmVelocity = 5000;
  TurnTableVelocity = 5000;
  WheelPower = 0.5;
  AutoArm = false;
  AutoIntake = false;
  AutoTurnTable = false;
  RobotPosition = 'R';
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    MoveTurnTablePosition('C');
    MovetoHub();
    DropBlock();
    Moving_to_RedAllianceWarehouse();
    telemetry.update();
  }
  tfodCurrentGameAccess.deactivate();
}

/**
 * Describe this function...
 */
function DetectDuckPosition() {
  vuforiaCurrentGameAccess.initialize_withWebcam_2("Webcam 1", '', false, false, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  tfodCurrentGameAccess.initialize(vuforiaCurrentGameAccess, 0.7, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodCurrentGameAccess.activate();
  tfodCurrentGameAccess.setZoom(1, 16 / 9);
  telemetryAddTextData('DS preview on/off', '3 dots, Camera Stream');
  telemetryAddTextData('>', 'Press Play to start');
  telemetry.update();
  // Get a list of recognitions from TFOD.
  recognitions = JSON.parse(tfodCurrentGameAccess.getRecognitions());
  // If list is empty, inform the user. Otherwise, go
  // through list and display info for each recognition.
  if (recognitions.length == 0) {
    location2 = 'RIGHT';
    telemetryAddTextData('default position', location2);
  } else {
    // Iterate through list and call a function to
    // display info for each recognized object.
    for (var recognition_index in recognitions) {
      recognition = recognitions[recognition_index];
      if (recognition.Label == 'Duck') {
        determineLocation();
      }
    }
  }
}

/**
 * Describe this function...
 */
function IMU_Calibrated() {
  telemetryAddTextData('IMU Calibration Status', imuAsBNO055IMU.getCalibrationStatus());
  telemetryAddTextData('Gyro Calibrated', imuAsBNO055IMU.isGyroCalibrated() ? 'True' : 'False');
  telemetryAddTextData('System Status', imuAsBNO055IMU.getSystemStatus());
  return imuAsBNO055IMU.isGyroCalibrated();
}

/**
 * Describe this function...
 */
function Move_ArmShippingHub_Auto(Position) {
  if (Position == 'A') {
    SetArmPosition(-996);
  } else if (Position == 'B') {
    SetArmPosition(-1987);
  } else if (Position == 'Y') {
    SetArmPosition(-3167);
  } else if (Position == 'X') {
    SetArmPosition(-1300);
  }
}

/**
 * Describe this function...
 */
function DropBlock() {
  if (location2 == 'CENTER') {
    telemetryAddTextData('Center', 'Center');
    Move_ArmShippingHub_Auto('B');
    intakeboxAsServo.setPosition(0.649);
  } else if (location2 == 'LEFT') {
    telemetryAddTextData('Lower', 'Lower');
    Move_ArmShippingHub_Auto('A');
    intakeboxAsServo.setPosition(0.89);
  } else {
    telemetryAddTextData('Top', 'Top');
    Move_ArmShippingHub_Auto('Y');
    intakeboxAsServo.setPosition(0.38);
  }
  intakeAsDcMotor.setPower(0.25);
  telemetry.update();
}

/**
 * Describe this function...
 */
function Set_Yaw_Angle() {
  Yaw_Angle = orientationAccess.getFirstAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "ZYX", "DEGREES"));
}

/**
 * Describe this function...
 */
function Initialize_IMU() {
  imuParameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setAngleUnit(imuParameters, "DEGREES");
  bno055imuParametersAccess.setAccelUnit(imuParameters, "METERS_PERSEC_PERSEC");
  bno055imuParametersAccess.setLoggingEnabled(imuParameters, false);
  imuAsBNO055IMU.initialize(imuParameters);
  while (!IMU_Calibrated()) {
    telemetryAddTextData('If calibration ', 'doesn\'t complete after 3 seconds, move through 90 degree pitch, roll and yaw motions until calibration complete ');
    telemetry.update();
    linearOpMode.sleep(1000);
  }
  telemetryAddTextData('Status', 'Calibration Complete');
  telemetry.update();
}

/**
 * Describe this function...
 */
function MovetoHub() {
  RobotMove(358, 359, 358, 353, 500);
  RobotMove(-39, 765, 773, -44, 500);
  RobotMove(1858, -1159, 2671, -1951, 1000);
  Move_Arm_Position(3);
  RobotMove(1489, -1543, 2313, -2338, 500);
  RobotMove(1337, -1699, 2164, -2486, 500);
}

/**
 * Describe this function...
 */
function RobotMove(FrontLeftTicks, FrontRightTicks, RearLeftTicks, RearRightTicks, Velocity) {
  frontLeftAsDcMotor.setDualTargetPosition(FrontLeftTicks, frontRightAsDcMotor, FrontRightTicks);
  rearLeftAsDcMotor.setDualTargetPosition(RearLeftTicks, rearRightAsDcMotor, RearRightTicks);
  frontLeftAsDcMotor.setDualMode("RUN_TO_POSITION", frontRightAsDcMotor, "RUN_TO_POSITION");
  rearLeftAsDcMotor.setDualMode("RUN_TO_POSITION", rearRightAsDcMotor, "RUN_TO_POSITION");
  frontLeftAsDcMotor.setDualVelocity(Velocity, frontRightAsDcMotor, Velocity);
  rearLeftAsDcMotor.setDualVelocity(Velocity, rearRightAsDcMotor, Velocity);
  while (frontLeftAsDcMotor.isBusy() || frontRightAsDcMotor.isBusy() || rearLeftAsDcMotor.isBusy() || rearRightAsDcMotor.isBusy()) {
    Set_Yaw_Angle();
    telemetryAddTextData('Yaw Angle', Yaw_Angle);
  }
}

/**
 * Describe this function...
 */
function Moving_to_RedAllianceWarehouse() {
  Move_Arm_Position(0);
  RobotMove(517, -856, 1389, -1724, 500);
  RobotMove(3361, 2148, 4180, 1095, 2000);
}

/**
 * Describe this function...
 */
function determineLocation() {
  xPosition = miscAccess.roundDecimal(recognition.Left, 0);
  if (xPosition <= 105) {
    location2 = 'LEFT';
  } else if (xPosition > 400) {
    location2 = 'RIGHT';
  } else {
    location2 = 'CENTER';
  }
  telemetryAddTextData('ducky Position', xPosition);
  telemetryAddTextData('ducky location', location2);
  linearOpMode.sleep(20000);
}

/**
 * Describe this function...
 */
function ResetArmDown() {
  if (!armdowntouchAsTouchSensor.getIsPressed()) {
    armAsDcMotor.setTargetPosition(5000);
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(1500);
    while (!armdowntouchAsTouchSensor.getIsPressed()) {
      telemetry.addNumericData('Reset Arm Position', armAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
    armAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    SetArmPosition(0);
  }
}

/**
 * Describe this function...
 */
function ResetArmUp() {
  if (!armuptouchAsTouchSensor.getIsPressed()) {
    armAsDcMotor.setTargetPosition(-5000);
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(1500);
    while (!armuptouchAsTouchSensor.getIsPressed()) {
      telemetry.addNumericData('Reset Arm Position', armAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
    armAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    SetArmPosition(80);
  }
}

/**
 * Describe this function...
 */
function SetTurnTablePosition(Position) {
  AutoTurnTable = true;
  turntableAsDcMotor.setTargetPosition(Position);
  turntableAsDcMotor.setMode("RUN_TO_POSITION");
  turntableAsDcMotor.setVelocity(TurnTableVelocity);
}

/**
 * Describe this function...
 */
function ResetTurnTable() {
  if (!turntabletouchAsTouchSensor.getIsPressed()) {
    turntableAsDcMotor.setTargetPosition(-5000);
    turntableAsDcMotor.setMode("RUN_TO_POSITION");
    turntableAsDcMotor.setVelocity(1500);
    while (!turntabletouchAsTouchSensor.getIsPressed()) {
      telemetry.addNumericData('Reset Turn Table Position', turntableAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
    turntableAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
    SetTurnTablePosition(100);
  }
}

/**
 * Describe this function...
 */
function ResetArmNTurnTableAuto() {
  intakeboxAsServo.setPosition(0.27);
  ResetArmUp();
  ResetTurnTable();
  ResetArmDown();
}

/**
 * Describe this function...
 */
function SetArmPosition(Position) {
  AutoArm = true;
  armAsDcMotor.setTargetPosition(Position);
  armAsDcMotor.setMode("RUN_TO_POSITION");
  armAsDcMotor.setVelocity(ArmVelocity);
}

/**
 * Describe this function...
 */
function Move_Arm_Position(Position) {
}
