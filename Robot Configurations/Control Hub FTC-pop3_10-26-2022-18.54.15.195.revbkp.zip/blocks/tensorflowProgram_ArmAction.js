var xPosition, location2, recognition, recognitions;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  vuforiaCurrentGameAccess.initialize_withWebcam_2("Webcam 1", '', false, false, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  tfodCurrentGameAccess.initialize(vuforiaCurrentGameAccess, 0.7, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodCurrentGameAccess.activate();
  tfodCurrentGameAccess.setZoom(1.2, 16 / 9);
  telemetryAddTextData('DS preview on/off', '3 dots, Camera Stream');
  telemetryAddTextData('>', 'Press Play to start');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    // Get a list of recognitions from TFOD.
    recognitions = JSON.parse(tfodCurrentGameAccess.getRecognitions());
    // If list is empty, inform the user. Otherwise, go
    // through list and display info for each recognition.
    if (recognitions.length == 0) {
      location2 = 'CENTER';
      telemetryAddTextData('default position', location2);
      telemetry.update();
    } else {
      // Iterate through list and call a function to
      // display info for each recognized object.
      for (var recognition_index in recognitions) {
        recognition = recognitions[recognition_index];
        if (recognition.Label == 'Duck') {
          determineLocation();
        }
      }
    }
    takeaction();
  }
  tfodCurrentGameAccess.deactivate();
}

/**
 * Describe this function...
 */
function determineLocation() {
  xPosition = miscAccess.roundDecimal(recognition.Left, 0);
  if (xPosition <= 105) {
    location2 = 'LEFT';
  } else if (xPosition > 400) {
    location2 = 'RIGHT';
  } else {
    location2 = 'CENTER';
  }
  telemetryAddTextData('ducky Position', xPosition);
  telemetryAddTextData('ducky location', location2);
  telemetry.update();
}

/**
 * Describe this function...
 */
function takeaction() {
  armMotorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  flapperMotorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  if (location2 == 'CENTER') {
    armMotorAsDcMotor.setTargetPosition(400);
  } else if (location2 == 'RIGHT') {
    rightAsDcMotor.setTargetPosition(200);
  } else {
    armMotorAsDcMotor.setTargetPosition(75);
  }
  armMotorAsDcMotor.setMode("RUN_TO_POSITION");
  armMotorAsDcMotor.setVelocity(200);
  while (armMotorAsDcMotor.isBusy()) {
  }
  DropBlock();
  armMotorAsDcMotor.setVelocity(0);
  flapperMotorAsDcMotor.setVelocity(0);
}

/**
 * Describe this function...
 */
function DropBlock() {
  flapperMotorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  flapperMotorAsDcMotor.setTargetPosition(-600);
  flapperMotorAsDcMotor.setMode("RUN_TO_POSITION");
  flapperMotorAsDcMotor.setVelocity(2000);
  while (flapperMotorAsDcMotor.isBusy()) {
    telemetryAddTextData('Is Dropping the Block?', 'Yes');
    telemetry.addNumericData('Flapper Velocity ', leftAsDcMotor.getVelocity());
    telemetryAddTextData('Position', flapperMotorAsDcMotor.getCurrentPosition());
    telemetry.update();
  }
}
