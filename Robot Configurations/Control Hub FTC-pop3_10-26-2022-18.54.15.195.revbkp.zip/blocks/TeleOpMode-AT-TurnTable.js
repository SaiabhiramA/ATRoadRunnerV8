var power, Position, imuParameters, Yaw_Angle, isAutoArm, WheelPower, ArmVelocity, AutoIntake, TurnTableVelocity;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  frontLeftAsDcMotor.setDirection("REVERSE");
  rearLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDualZeroPowerBehavior("BRAKE", frontRightAsDcMotor, "BRAKE");
  rearLeftAsDcMotor.setDualZeroPowerBehavior("BRAKE", rearRightAsDcMotor, "BRAKE");
  intakeAsDcMotor.setZeroPowerBehavior("BRAKE");
  armAsDcMotor.setZeroPowerBehavior("BRAKE");
  carosuelmoterAsDcMotor.setZeroPowerBehavior("BRAKE");
  frontLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", frontRightAsDcMotor, "STOP_AND_RESET_ENCODER");
  rearLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rearRightAsDcMotor, "STOP_AND_RESET_ENCODER");
  frontLeftAsDcMotor.setDualMode("RUN_WITHOUT_ENCODER", frontRightAsDcMotor, "RUN_WITHOUT_ENCODER");
  rearLeftAsDcMotor.setDualMode("RUN_WITHOUT_ENCODER", rearRightAsDcMotor, "RUN_WITHOUT_ENCODER");
  intakeAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  carosuelmoterAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  armAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  turntableAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  ArmVelocity = 500;
  WheelPower = 0.5;
  isAutoArm = false;
  AutoIntake = false;
  TurnTableVelocity = 500;
  InitializeIMU();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      DriveOverall();
    }
  }
}

/**
 * Describe this function...
 */
function Zero_Power_Wheels() {
  frontLeftAsDcMotor.setDualPower(0, frontRightAsDcMotor, 0);
  rearLeftAsDcMotor.setDualPower(0, rearRightAsDcMotor, 0);
}

/**
 * Describe this function...
 */
function DriveOverall() {
  if (gamepad1.getLeftTrigger() > 0) {
    frontLeftAsDcMotor.setDualPower(Wheel_Power(-gamepad1.getLeftTrigger()), frontRightAsDcMotor, Wheel_Power(-gamepad1.getLeftTrigger()));
    rearLeftAsDcMotor.setDualPower(Wheel_Power(-gamepad1.getLeftTrigger()), rearRightAsDcMotor, Wheel_Power(-gamepad1.getLeftTrigger()));
  } else if (gamepad1.getLeftStickX() != 0) {
    frontLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getLeftStickX()), frontRightAsDcMotor, Wheel_Power(-gamepad1.getLeftStickX()));
    rearLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getLeftStickX()), rearRightAsDcMotor, Wheel_Power(-gamepad1.getLeftStickX()));
  } else if (gamepad1.getRightTrigger() > 0) {
    frontLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getRightTrigger()), frontRightAsDcMotor, Wheel_Power(gamepad1.getRightTrigger()));
    rearLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getRightTrigger()), rearRightAsDcMotor, Wheel_Power(gamepad1.getRightTrigger()));
  } else if (gamepad1.getRightStickX() != 0) {
    frontLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getRightStickX()), frontRightAsDcMotor, Wheel_Power(-gamepad1.getRightStickX()));
    rearLeftAsDcMotor.setDualPower(Wheel_Power(-gamepad1.getRightStickX()), rearRightAsDcMotor, Wheel_Power(gamepad1.getRightStickX()));
  } else if (gamepad1.getLeftBumper() == true && gamepad1.getLeftStickY() != 0) {
    frontLeftAsDcMotor.setDualPower(0, frontRightAsDcMotor, Wheel_Power(gamepad1.getLeftStickY()));
    rearLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getLeftStickY()), rearRightAsDcMotor, 0);
  } else if (gamepad1.getRightBumper() == true && gamepad1.getRightStickY() != 0) {
    frontLeftAsDcMotor.setDualPower(Wheel_Power(gamepad1.getRightStickY()), frontRightAsDcMotor, 0);
    rearLeftAsDcMotor.setDualPower(0, rearRightAsDcMotor, Wheel_Power(gamepad1.getRightStickY()));
  } else {
    Zero_Power_Wheels();
  }
}

/**
 * Describe this function...
 */
function Move_Arm_Auto() {
  if (gamepad2.getA()) {
    SetArmPosition(-9291);
  } else if (gamepad2.getB()) {
    SetArmPosition(-8546);
  } else if (gamepad2.getY()) {
    SetArmPosition(-7480);
  } else if (gamepad2.getX()) {
    SetArmPosition(-800);
  }
}

/**
 * Describe this function...
 */
function CheckNSetTurboMode() {
  if (gamepad1.getB()) {
    WheelPower = 1;
  } else if (gamepad1.getX()) {
    WheelPower = 0.5;
  }
}

/**
 * Describe this function...
 */
function Display_Gamepad_1() {
  telemetry.addNumericData('Right Trigger', gamepad1.getRightTrigger());
  telemetry.addNumericData('Left Trigger', gamepad1.getLeftTrigger());
  telemetry.addNumericData('Left Stick X', gamepad1.getLeftStickX());
  telemetry.addNumericData('Left Stick Y', gamepad1.getLeftStickY());
  telemetry.addNumericData('Right Stick X', gamepad1.getRightStickX());
  telemetry.addNumericData('Right Stick Y', gamepad1.getRightStickY());
  telemetryAddTextData('A Button', gamepad1.getA());
  telemetryAddTextData('B Button', gamepad1.getB());
  telemetryAddTextData('X Button', gamepad1.getX());
  telemetryAddTextData('Y button', gamepad1.getY());
  telemetryAddTextData('DPad Down', gamepad1.getDpadDown());
  telemetryAddTextData('DPad Left', gamepad1.getDpadLeft());
  telemetryAddTextData('DPad Right', gamepad1.getDpadRight());
  telemetryAddTextData('DPad Up', gamepad1.getDpadUp());
  telemetryAddTextData('Left Bumper', gamepad1.getLeftBumper());
  telemetryAddTextData('Right Bumper', gamepad1.getRightBumper());
  telemetryAddTextData('Right Stick Pressed', gamepad1.getRightStickButton());
  telemetryAddTextData('Left Stick Pressed', gamepad1.getLeftStickButton());
  telemetry.update();
}

/**
 * Describe this function...
 */
function InitializeIMU() {
  imuParameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setAngleUnit(imuParameters, "DEGREES");
  bno055imuParametersAccess.setAccelUnit(imuParameters, "METERS_PERSEC_PERSEC");
  bno055imuParametersAccess.setLoggingEnabled(imuParameters, false);
  imuAsBNO055IMU.initialize(imuParameters);
  telemetryAddTextData('IMU Example', 'Press start to continue...');
  telemetry.update();
}

/**
 * Describe this function...
 */
function Display_Gamepad_2() {
  telemetry.addNumericData('Right Trigger', gamepad2.getRightTrigger());
  telemetry.addNumericData('Left Trigger', gamepad2.getLeftTrigger());
  telemetry.addNumericData('Left Stick X', gamepad2.getLeftStickX());
  telemetry.addNumericData('Left Stick Y', gamepad2.getLeftStickY());
  telemetry.addNumericData('Right Stick X', gamepad2.getRightStickX());
  telemetry.addNumericData('Right Stick Y', gamepad2.getRightStickY());
  telemetryAddTextData('A Button', gamepad2.getA());
  telemetryAddTextData('B Button', gamepad2.getB());
  telemetryAddTextData('X Button', gamepad2.getX());
  telemetryAddTextData('Y button', gamepad2.getY());
  telemetryAddTextData('DPad Down', gamepad2.getDpadDown());
  telemetryAddTextData('DPad Left', gamepad2.getDpadLeft());
  telemetryAddTextData('DPad Right', gamepad2.getDpadRight());
  telemetryAddTextData('DPad Up', gamepad2.getDpadUp());
  telemetryAddTextData('Left Bumper', gamepad2.getLeftBumper());
  telemetryAddTextData('Right Bumper', gamepad2.getRightBumper());
  telemetryAddTextData('Right Stick Pressed', gamepad2.getRightStickButton());
  telemetryAddTextData('Left Stick Pressed', gamepad2.getLeftStickButton());
}

/**
 * Describe this function...
 */
function targetPosition(power) {
  return 1000 * power;
}

/**
 * Describe this function...
 */
function Wheel_Power(power) {
  return WheelPower * power;
}

/**
 * Describe this function...
 */
function Arm_Velocity(power) {
  return ArmVelocity * power;
}

/**
 * Describe this function...
 */
function Reset_Arm() {
  ArmmotorAsDcMotor.setTargetPosition(12000);
  ArmmotorAsDcMotor.setMode("RUN_TO_POSITION");
  ArmmotorAsDcMotor.setVelocity(ArmVelocity);
  while (!armtouchsensorAsTouchSensor.getIsPressed()) {
    telemetry.addNumericData('Reset Arm Position', ArmmotorAsDcMotor.getCurrentPosition());
  }
  ArmmotorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  ArmmotorAsDcMotor.setTargetPosition(-800);
  ArmmotorAsDcMotor.setMode("RUN_TO_POSITION");
  ArmmotorAsDcMotor.setVelocity(ArmVelocity);
}

/**
 * Describe this function...
 */
function ResetEncoders() {
  if (gamepad1.getDpadUp() == true) {
    frontLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", frontRightAsDcMotor, "STOP_AND_RESET_ENCODER");
    rearLeftAsDcMotor.setDualMode("STOP_AND_RESET_ENCODER", rearRightAsDcMotor, "STOP_AND_RESET_ENCODER");
    frontLeftAsDcMotor.setDualMode("RUN_WITHOUT_ENCODER", frontRightAsDcMotor, "RUN_WITHOUT_ENCODER");
    rearLeftAsDcMotor.setDualMode("RUN_WITHOUT_ENCODER", rearRightAsDcMotor, "RUN_WITHOUT_ENCODER");
  }
}

/**
 * Describe this function...
 */
function Set_Yaw_Angle() {
  Yaw_Angle = orientationAccess.getFirstAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "ZYX", "DEGREES"));
}

/**
 * Describe this function...
 */
function Display_Key_Measures() {
  telemetryAddTextData('Front Left Position', frontLeftAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Front Right Position', frontRightAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Rear Left Position', rearLeftAsDcMotor.getCurrentPosition());
  telemetryAddTextData('Rear Right Position', rearRightAsDcMotor.getCurrentPosition());
  Set_Yaw_Angle();
  telemetry.addNumericData('Yaw Angle', Yaw_Angle);
  telemetry.update();
}

/**
 * Describe this function...
 */
function MoveArmManual() {
  if (gamepad2.getRightTrigger() > 0 && !armtouchsensorAsTouchSensor.getIsPressed()) {
    isAutoArm = false;
    armAsDcMotor.setTargetPosition(armAsDcMotor.getTargetPosition() + targetPosition(gamepad2.getRightTrigger()));
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(ArmVelocity);
  } else if (gamepad2.getLeftTrigger() > 0) {
    isAutoArm = false;
    armAsDcMotor.setTargetPosition(armAsDcMotor.getTargetPosition() - targetPosition(gamepad2.getLeftTrigger()));
    armAsDcMotor.setMode("RUN_TO_POSITION");
    armAsDcMotor.setVelocity(ArmVelocity);
  } else if (isAutoArm == false) {
    armAsDcMotor.setTargetPosition(armAsDcMotor.getCurrentPosition());
    armAsDcMotor.setVelocity(armAsDcMotor.getVelocity());
  }
}

/**
 * Describe this function...
 */
function MoveAutoIntake() {
  if (gamepad2.getDpadLeft() || AutoIntake) {
    intakeAsDcMotor.setPower(-0.75);
    AutoIntake = true;
    if (intaketohchAsTouchSensor.getIsPressed()) {
      intakeAsDcMotor.setPower(0);
      AutoIntake = false;
      frontLeftAsDcMotor.setDualPower(Wheel_Power(-1), frontRightAsDcMotor, Wheel_Power(-1));
      rearLeftAsDcMotor.setDualPower(Wheel_Power(-1), rearRightAsDcMotor, Wheel_Power(-1));
      linearOpMode.sleep(50);
      SetArmPosition(-4000);
    }
  }
  if (gamepad2.getDpadDown() && !armtouchsensorAsTouchSensor.getIsPressed()) {
    SetArmPosition(-50);
  }
  if (gamepad2.getDpadRight()) {
    AutoIntake = false;
    intakeAsDcMotor.setPower(0);
  }
  if (AutoIntake != true) {
    if (gamepad2.getRightStickX() < 0 && gamepad2.getRightBumper() != true) {
      intakeAsDcMotor.setPower(gamepad2.getRightStickX());
    } else if (gamepad2.getRightStickX() > 0 && gamepad2.getRightBumper() != true) {
      intakeAsDcMotor.setPower(-0.25);
    } else if (gamepad2.getRightStickX() != 0 && gamepad2.getRightBumper() == true) {
      intakeAsDcMotor.setPower(-gamepad2.getRightStickX());
    } else {
      intakeAsDcMotor.setPower(0);
    }
  }
}

/**
 * Describe this function...
 */
function Move_Carousel() {
  if (gamepad2.getLeftStickX() != 0) {
    carosuelmoterAsDcMotor.setPower(0.4 * gamepad2.getLeftStickX());
  } else {
    carosuelmoterAsDcMotor.setPower(0);
  }
}

/**
 * Describe this function...
 */
function AutoSpinCarousel() {
  if (gamepad1.getY()) {
    carosuelmoterAsDcMotor.setPower(-0.05);
    for (var count = 0; count < 8; count++) {
      carosuelmoterAsDcMotor.setPower(carosuelmoterAsDcMotor.getPower() - 0.05);
      linearOpMode.sleep(250);
    }
  }
  if (gamepad1.getA()) {
    carosuelmoterAsDcMotor.setPower(0.05);
    for (var count2 = 0; count2 < 8; count2++) {
      carosuelmoterAsDcMotor.setPower(carosuelmoterAsDcMotor.getPower() + 0.05);
      linearOpMode.sleep(250);
    }
  }
  carosuelmoterAsDcMotor.setPower(0);
}

/**
 * Describe this function...
 */
function SetArmPosition(Position) {
  isAutoArm = true;
  ArmmotorAsDcMotor.setTargetPosition(Position);
  ArmmotorAsDcMotor.setMode("RUN_TO_POSITION");
  ArmmotorAsDcMotor.setVelocity(ArmVelocity);
}
