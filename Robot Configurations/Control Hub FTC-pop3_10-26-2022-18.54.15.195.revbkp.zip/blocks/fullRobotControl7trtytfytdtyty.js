var arm;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  arm = armMotorAsDcMotor.getCurrentPosition();
  leftAsDcMotor.setDirection("REVERSE");
  armMotorAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      rightAsDcMotor.setPower(-gamepad1.getLeftTrigger());
      leftAsDcMotor.setPower(-gamepad1.getLeftTrigger());
      rightAsDcMotor.setPower(gamepad1.getRightTrigger());
      leftAsDcMotor.setPower(gamepad1.getRightTrigger());
      rightAsDcMotor.setPower(gamepad1.getRightStickX());
      leftAsDcMotor.setPower(-gamepad1.getRightStickX());
      armMotorAsDcMotor.setPower(gamepad2.getRightStickY());
      flapperMotorAsDcMotor.setPower(gamepad2.getLeftStickY());
      flywheelservoAsCRServo.setPower(gamepad2.getLeftTrigger());
      telemetryAddTextData('Arm current status', arm);
      telemetry.update();
    }
  }
}
