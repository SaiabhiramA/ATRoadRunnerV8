package org.firstinspires.ftc.teamcode;

import String;
import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.TouchSensor;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;

@TeleOp(name = "KetteringQualifierGameDayTeleop (Blocks to Java)")
public class KetteringQualifierGameDayTeleop extends LinearOpMode {

  private DcMotor turntable;
  private DcMotor arm;
  private TouchSensor armuptouch;
  private DcMotor intake;
  private DcMotor carosuelmoter;
  private DcMotor frontLeft;
  private DcMotor rearLeft;
  private DcMotor frontRight;
  private DcMotor rearRight;
  private Servo intakebox;
  private BNO055IMU imu;
  private TouchSensor armdowntouch;
  private TouchSensor turntabletouch;

  int TurnTableCurrentPosition;
  int ArmCurrentPosition;
  boolean AutoArm;
  boolean AutoTurnTable;
  float Yaw_Angle;
  boolean AutoIntake;
  double WheelPower;
  int ArmVelocity;
  int TurnTableVelocity2;

  /**
   * Describe this function...
   */
  private void MoveArmManual() {
    TurnTableCurrentPosition = turntable.getCurrentPosition();
    ArmCurrentPosition = arm.getCurrentPosition();
    if (gamepad2.left_trigger > 0 && gamepad2.left_bumper != true) {
      if (!armuptouch.isPressed()) {
        AutoArm = false;
        arm.setTargetPosition((int) (arm.getTargetPosition() - targetposition(gamepad2.left_trigger)));
        arm.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        ((DcMotorEx) arm).setVelocity(1000);
      }
    } else if (gamepad2.right_trigger > 0 && gamepad2.right_bumper != true && ArmCurrentPosition < -450) {
      telemetry.addData("Yes less than -450", ArmCurrentPosition);
      ArmCurrentPosition = arm.getCurrentPosition();
      if (TurnTableCurrentPosition < 450 && TurnTableCurrentPosition > 150 || TurnTableCurrentPosition < 8750 && TurnTableCurrentPosition > 8550) {
        AutoArm = false;
        arm.setTargetPosition((int) (arm.getTargetPosition() + targetposition(gamepad2.right_trigger)));
        arm.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        ((DcMotorEx) arm).setVelocity(1000);
      }
    } else if (AutoArm == false) {
      arm.setTargetPosition(arm.getCurrentPosition());
      ((DcMotorEx) arm).setVelocity(((DcMotorEx) arm).getVelocity());
    }
  }

  /**
   * Describe this function...
   */
  private void Move_Intake_Manually() {
    if (gamepad2.right_stick_x != 0 && gamepad2.right_bumper == false) {
      AutoIntake = false;
      if (gamepad2.right_stick_x > 0) {
        intake.setPower(0.25);
      } else if (gamepad2.right_stick_x < 0) {
        intake.setPower(-0.75);
      }
    } else if (AutoIntake == false) {
      intake.setPower(0);
    }
  }

  /**
   * Describe this function...
   */
  private void Move_Carousel() {
    if (gamepad1.left_bumper == true && gamepad1.left_stick_x != 0) {
      // Move Carousel when Left Stick X is Pressed
      carosuelmoter.setPower(1 * gamepad2.left_stick_x);
    } else {
      carosuelmoter.setPower(0);
    }
  }

  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    turntable = hardwareMap.get(DcMotor.class, "turntable");
    arm = hardwareMap.get(DcMotor.class, "arm");
    armuptouch = hardwareMap.get(TouchSensor.class, "armuptouch");
    intake = hardwareMap.get(DcMotor.class, "intake");
    carosuelmoter = hardwareMap.get(DcMotor.class, "carosuelmoter");
    frontLeft = hardwareMap.get(DcMotor.class, "frontLeft");
    rearLeft = hardwareMap.get(DcMotor.class, "rearLeft");
    frontRight = hardwareMap.get(DcMotor.class, "frontRight");
    rearRight = hardwareMap.get(DcMotor.class, "rearRight");
    intakebox = hardwareMap.get(Servo.class, "intakebox");
    imu = hardwareMap.get(BNO055IMU.class, "imu");
    armdowntouch = hardwareMap.get(TouchSensor.class, "armdowntouch");
    turntabletouch = hardwareMap.get(TouchSensor.class, "turntabletouch");

    // Put initialization blocks here.
    frontLeft.setDirection(DcMotorSimple.Direction.REVERSE);
    rearLeft.setDirection(DcMotorSimple.Direction.REVERSE);
    frontLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    frontRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    rearLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    rearRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    intake.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    intake.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    frontLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    frontRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    rearLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    rearRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    ArmVelocity = 1000;
    TurnTableVelocity2 = 1000;
    WheelPower = 0.5;
    AutoArm = false;
    AutoIntake = false;
    AutoTurnTable = false;
    InitializeIMU();
    ResetArmNTurnTableAuto();
    waitForStart();
    if (opModeIsActive()) {
      // Put run blocks here.
      while (opModeIsActive()) {
        // Put loop blocks here.
        DriveOverall();
        Move_Carousel();
        AutoSpinCarousel();
        MoveIntakeBoxManually();
        Move_Intake_Manually();
        Move_Intake_Auto();
        MoveArmManual();
        MoveTurnTableManual();
        CheckNSetTurboMode();
        ResetEncoders();
        Display_Key_Measures();
        TuneIntakeBox();
        Reset_ArmNTurnTableManually();
        DropShippingElementCenter();
        DropShippingElementLeft();
        DropShippingElementRight();
        Move_ArmShippingHub_Auto(null);
        telemetry.update();
      }
    }
  }

  /**
   * Describe this function...
   */
  private double Wheel_Power(float power) {
    return WheelPower * power;
  }

  /**
   * Describe this function...
   */
  private double Arm_Velocity(double power) {
    return ArmVelocity * power;
  }

  /**
   * Describe this function...
   */
  private void AutoSpinCarousel() {
    if (gamepad1.y) {
      // Red alliance Carousel
      carosuelmoter.setPower(-0.05);
      for (int count = 0; count < 8; count++) {
        carosuelmoter.setPower(carosuelmoter.getPower() - 0.05);
        sleep(250);
      }
    }
    if (gamepad1.a) {
      // Blue alliance Carousel
      carosuelmoter.setPower(0.05);
      for (int count2 = 0; count2 < 8; count2++) {
        carosuelmoter.setPower(carosuelmoter.getPower() + 0.05);
        sleep(250);
      }
    }
    carosuelmoter.setPower(0);
  }

  /**
   * Describe this function...
   */
  private double TurnTableVelocity(double power) {
    return TurnTableVelocity2 * power;
  }

  /**
   * Describe this function...
   */
  private void Move_Intake_Auto() {
    if (gamepad2.dpad_left && !gamepad2.left_bumper) {
      SetArmPosition(-2500);
      while (!(arm.getCurrentPosition() == -2500)) {
      }
      SetTurnTablePosition(4350);
      while (!(turntable.getCurrentPosition() == 4350)) {
      }
      SetArmPosition(-50);
      intakebox.setPosition(0.649);
      AutoIntake = true;
    }
    if (gamepad2.dpad_down && !gamepad2.left_bumper) {
      SetArmPosition(-50);
    }
    if (gamepad2.dpad_right && !gamepad2.left_bumper) {
      AutoIntake = false;
      intake.setPower(0);
    }
  }

  /**
   * Describe this function...
   */
  private float targetposition(float power) {
    return 10000 * power;
  }

  /**
   * Describe this function...
   */
  private void MoveTurnTableManual() {
    ArmCurrentPosition = arm.getCurrentPosition();
    TurnTableCurrentPosition = turntable.getCurrentPosition();
    if (ArmCurrentPosition < -1000) {
      if (TurnTableCurrentPosition < 8700 && gamepad2.left_trigger > 0 && gamepad2.left_bumper == true) {
        AutoTurnTable = false;
        turntable.setTargetPosition((int) (turntable.getTargetPosition() + targetposition(gamepad2.left_trigger)));
        turntable.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        ((DcMotorEx) turntable).setVelocity(1000);
      } else if (TurnTableCurrentPosition > 200 && gamepad2.right_trigger > 0 && gamepad2.right_bumper == true) {
        AutoTurnTable = false;
        turntable.setTargetPosition((int) (turntable.getTargetPosition() - targetposition(gamepad2.right_trigger)));
        turntable.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        ((DcMotorEx) turntable).setVelocity(1000);
      } else if (AutoTurnTable == false) {
        turntable.setTargetPosition(turntable.getCurrentPosition());
        ((DcMotorEx) turntable).setVelocity(((DcMotorEx) turntable).getVelocity());
      }
    }
  }

  /**
   * Describe this function...
   */
  private void Zero_Power_Wheels() {
    frontLeft.setPower(0);
    frontRight.setPower(0);
    rearLeft.setPower(0);
    rearRight.setPower(0);
  }

  /**
   * Describe this function...
   */
  private void CheckNSetTurboMode() {
    if (gamepad1.b) {
      WheelPower = 1;
    } else if (gamepad1.x) {
      WheelPower = 0.5;
    }
  }

  /**
   * Describe this function...
   */
  private void DriveOverall() {
    if (gamepad1.left_trigger > 0) {
      // Move Backward when LeftTrigger is Pressed
      frontLeft.setPower(Wheel_Power(-gamepad1.left_trigger));
      frontRight.setPower(Wheel_Power(-gamepad1.left_trigger));
      rearLeft.setPower(Wheel_Power(-gamepad1.left_trigger));
      rearRight.setPower(Wheel_Power(-gamepad1.left_trigger));
    } else if (gamepad1.left_stick_x != 0 && gamepad1.left_bumper == false) {
      // Turn Right when Left Sick is moved to the Right
      // Turn Left when Left Sick is moved to the Left
      frontLeft.setPower(Wheel_Power(gamepad1.left_stick_x));
      frontRight.setPower(Wheel_Power(-gamepad1.left_stick_x));
      rearLeft.setPower(Wheel_Power(gamepad1.left_stick_x));
      rearRight.setPower(Wheel_Power(-gamepad1.left_stick_x));
    } else if (gamepad1.right_trigger > 0) {
      // Move Forward when RightTrigger is Pressed
      frontLeft.setPower(Wheel_Power(gamepad1.right_trigger));
      frontRight.setPower(Wheel_Power(gamepad1.right_trigger));
      rearLeft.setPower(Wheel_Power(gamepad1.right_trigger));
      rearRight.setPower(Wheel_Power(gamepad1.right_trigger));
    } else if (gamepad1.right_stick_x != 0) {
      // Move Left when Right Sick is moved to the Left
      // Move Right when Right Sick is moved to the Right
      frontLeft.setPower(Wheel_Power(gamepad1.right_stick_x));
      frontRight.setPower(Wheel_Power(-gamepad1.right_stick_x));
      rearLeft.setPower(Wheel_Power(-gamepad1.right_stick_x));
      rearRight.setPower(Wheel_Power(gamepad1.right_stick_x));
    } else if (gamepad1.left_bumper == true && gamepad1.left_stick_y != 0) {
      // Move on Left Diagonal Up & Down when Left Sick Y
      frontLeft.setPower(0);
      frontRight.setPower(Wheel_Power(gamepad1.left_stick_y));
      rearLeft.setPower(Wheel_Power(gamepad1.left_stick_y));
      rearRight.setPower(0);
    } else if (gamepad1.right_bumper == true && gamepad1.right_stick_y != 0) {
      // Move on Right Diagonal Up & Down when Right Sick Y
      frontLeft.setPower(Wheel_Power(gamepad1.right_stick_y));
      frontRight.setPower(0);
      rearLeft.setPower(0);
      rearRight.setPower(Wheel_Power(gamepad1.right_stick_y));
    } else {
      Zero_Power_Wheels();
    }
  }

  /**
   * Describe this function...
   */
  private void ResetEncoders() {
    if (gamepad1.dpad_up == true) {
      frontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
      frontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
      rearLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
      rearRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
      frontLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
      frontRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
      rearLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
      rearRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
      turntable.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
      arm.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    }
  }

  /**
   * Describe this function...
   */
  private void SetTurnTablePosition(int Position2) {
    AutoTurnTable = true;
    turntable.setTargetPosition(Position2);
    turntable.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    ((DcMotorEx) turntable).setVelocity(ArmVelocity);
  }

  /**
   * Describe this function...
   */
  private void SetArmPosition(int Position2) {
    AutoArm = true;
    arm.setTargetPosition(Position2);
    arm.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    ((DcMotorEx) arm).setVelocity(ArmVelocity);
  }

  /**
   * Describe this function...
   */
  private void Move_ArmShippingHub_Auto(String Position2) {
    if (Position2.equals("A")) {
      // Lower Shelf of Shipping Hub
      SetArmPosition(-996);
      intakebox.setPosition(0.85);
    } else if (Position2.equals("B")) {
      // Middle Shelf of Shipping Hub
      SetArmPosition(-1987);
      intakebox.setPosition(0.71);
    } else if (Position2.equals("Y")) {
      // Top Shelf of Shipping Hub
      SetArmPosition(-3167);
      intakebox.setPosition(0.38);
    } else if (Position2.equals("X")) {
      // Warehouse Clearance & Shared Shipping Hub
      SetArmPosition(-500);
      intakebox.setPosition(0.649);
    }
  }

  /**
   * Describe this function...
   */
  private void DropShippingElementCenter2() {
    if (gamepad2.a) {
      TurnTablePosition("C");
      // Lower Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("A");
    } else if (gamepad2.b) {
      TurnTablePosition("C");
      // Middle Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("B");
    } else if (gamepad2.y) {
      TurnTablePosition("C");
      // Top Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("Y");
    } else if (gamepad2.x) {
      TurnTablePosition("C");
      // Warehouse Clearance
      Move_ArmShippingHub_Auto("X");
    }
  }

  /**
   * Describe this function...
   */
  private void MoveIntakeBoxManually() {
    if (gamepad2.left_bumper == true && gamepad2.dpad_up == true) {
      intakebox.setPosition(0.89);
      // Lower Shelf
    } else if (gamepad2.left_bumper == true && gamepad2.dpad_left == true) {
      intakebox.setPosition(0.649);
      // Middle shelf drop
    } else if (gamepad2.left_bumper == true && gamepad2.dpad_right == true) {
      intakebox.setPosition(0.71);
      // Intake
    } else if (gamepad2.left_bumper == true && gamepad2.dpad_down == true) {
      intakebox.setPosition(0.38);
      // Top shelf drpop and Shared Hub
    }
  }

  /**
   * Describe this function...
   */
  private void InitializeIMU() {
    BNO055IMU.Parameters imuParameters;

    imuParameters = new BNO055IMU.Parameters();
    // Use degrees as angle unit.
    imuParameters.angleUnit = BNO055IMU.AngleUnit.DEGREES;
    // Express acceleration as m/s^2.
    imuParameters.accelUnit = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
    // Disable logging.
    imuParameters.loggingEnabled = false;
    // Initialize IMU.
    imu.initialize(imuParameters);
    // Prompt user to press start buton.
    telemetry.addData("IMU Example", "Press start to continue...");
    telemetry.update();
  }

  /**
   * Describe this function...
   */
  private void TuneIntakeBox() {
    if (gamepad2.right_stick_x > 0 && gamepad2.right_bumper == true) {
      // Tune Intake Box
      intakebox.setPosition(gamepad2.right_stick_x);
    }
  }

  /**
   * Describe this function...
   */
  private void DropShippingElementRight() {
    if (gamepad2.a && gamepad2.left_bumper != true && gamepad2.right_bumper == true) {
      TurnTablePosition("R");
      // Lower Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("A");
    } else if (gamepad2.b && gamepad2.left_bumper != true && gamepad2.right_bumper == true) {
      TurnTablePosition("R");
      // Middle Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("B");
    } else if (gamepad2.y && gamepad2.left_bumper != true && gamepad2.right_bumper == true) {
      TurnTablePosition("R");
      // Top Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("Y");
    } else if (gamepad2.x && gamepad2.left_bumper != true && gamepad2.right_bumper == true) {
      TurnTablePosition("R");
      // Warehouse Clearance
      Move_ArmShippingHub_Auto("X");
    }
  }

  /**
   * Describe this function...
   */
  private void DropShippingElementCenter() {
    if (gamepad2.a && gamepad2.left_bumper != true && gamepad2.right_bumper != true) {
      TurnTablePosition("C");
      // Lower Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("A");
    } else if (gamepad2.b && gamepad2.left_bumper != true && gamepad2.right_bumper != true) {
      TurnTablePosition("C");
      // Middle Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("B");
    } else if (gamepad2.y && gamepad2.left_bumper != true && gamepad2.right_bumper != true) {
      TurnTablePosition("C");
      // Top Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("Y");
    } else if (gamepad2.x && gamepad2.left_bumper != true && gamepad2.right_bumper != true) {
      TurnTablePosition("C");
      // Warehouse Clearance
      Move_ArmShippingHub_Auto("X");
    }
  }

  /**
   * Describe this function...
   */
  private void Set_Yaw_Angle() {
    Yaw_Angle = imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES).firstAngle;
  }

  /**
   * Describe this function...
   */
  private void Reset_ArmNTurnTableManually() {
    if (gamepad1.left_bumper && gamepad1.right_bumper && gamepad1.left_trigger > 0 && gamepad1.right_trigger > 0) {
      ResetArmNTurnTableAuto();
    }
  }

  /**
   * Describe this function...
   */
  private void Display_Key_Measures() {
    telemetry.addData("Front Left Position", frontLeft.getCurrentPosition());
    telemetry.addData("Front Right Position", frontRight.getCurrentPosition());
    telemetry.addData("Rear Left Position", rearLeft.getCurrentPosition());
    telemetry.addData("Rear Right Position", rearRight.getCurrentPosition());
    telemetry.addData("Turn Table", turntable.getCurrentPosition());
    telemetry.addData("Arm", arm.getCurrentPosition());
    Set_Yaw_Angle();
    telemetry.addData("Yaw Angle", Yaw_Angle);
    telemetry.addData("Intake Box Position", intakebox.getPosition());
  }

  /**
   * Describe this function...
   */
  private void TurnTablePosition(String turntableposition) {
    if (turntableposition.equals("C")) {
      SetArmPosition(-2500);
      while (!(arm.getCurrentPosition() == -2500)) {
      }
      SetTurnTablePosition(4350);
      while (!(turntable.getCurrentPosition() == 4350)) {
      }
    } else if (turntableposition.equals("L")) {
      SetArmPosition(-2500);
      while (!(arm.getCurrentPosition() == -2500)) {
      }
      SetTurnTablePosition(8500);
      while (!(turntable.getCurrentPosition() == 8500)) {
      }
    } else if (turntableposition.equals("R")) {
      SetArmPosition(-2500);
      while (!(arm.getCurrentPosition() == -2500)) {
      }
      SetTurnTablePosition(500);
      while (!(turntable.getCurrentPosition() == 500)) {
      }
    }
  }

  /**
   * Describe this function...
   */
  private void ResetArmDown() {
    if (!armdowntouch.isPressed()) {
      arm.setTargetPosition(5000);
      arm.setMode(DcMotor.RunMode.RUN_TO_POSITION);
      ((DcMotorEx) arm).setVelocity(1000);
      while (!armdowntouch.isPressed()) {
        telemetry.addData("Reset Arm Position", arm.getCurrentPosition());
        telemetry.update();
      }
      arm.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
      SetArmPosition(0);
    }
  }

  /**
   * Describe this function...
   */
  private void ResetTurnTable() {
    if (!turntabletouch.isPressed()) {
      turntable.setTargetPosition(-5000);
      turntable.setMode(DcMotor.RunMode.RUN_TO_POSITION);
      ((DcMotorEx) turntable).setVelocity(1000);
      while (!turntabletouch.isPressed()) {
        telemetry.addData("Reset Turn Table Position", turntable.getCurrentPosition());
        telemetry.update();
      }
      turntable.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
      SetTurnTablePosition(100);
    }
  }

  /**
   * Describe this function...
   */
  private void DropShippingElementLeft() {
    if (gamepad2.a && gamepad2.left_bumper == true && gamepad2.right_bumper != true) {
      TurnTablePosition("L");
      // Lower Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("A");
    } else if (gamepad2.b && gamepad2.left_bumper == true && gamepad2.right_bumper != true) {
      TurnTablePosition("L");
      // Middle Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("B");
    } else if (gamepad2.y && gamepad2.left_bumper == true && gamepad2.right_bumper != true) {
      TurnTablePosition("L");
      // Top Shelf of Shipping Hub
      Move_ArmShippingHub_Auto("Y");
    } else if (gamepad2.x && gamepad2.left_bumper == true && gamepad2.right_bumper != true) {
      TurnTablePosition("L");
      // Warehouse Clearance
      Move_ArmShippingHub_Auto("X");
    }
  }

  /**
   * Describe this function...
   */
  private void ResetArmUp() {
    if (!armuptouch.isPressed()) {
      arm.setTargetPosition(-5000);
      arm.setMode(DcMotor.RunMode.RUN_TO_POSITION);
      ((DcMotorEx) arm).setVelocity(1000);
      while (!armuptouch.isPressed()) {
        telemetry.addData("Reset Arm Position", arm.getCurrentPosition());
        telemetry.update();
      }
      arm.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
      SetArmPosition(80);
    }
  }

  /**
   * Describe this function...
   */
  private void ResetArmNTurnTableAuto() {
    intakebox.setPosition(0.27);
    ResetArmUp();
    ResetTurnTable();
    ResetArmDown();
  }
}
